// src/index.ts
import { definePlugin } from "@t3tools/plugin-api";
import * as Effect5 from "effect/Effect";

// src/actions.ts
import { PendingRestore } from "@t3tools/plugin-api";
import * as Effect from "effect/Effect";
import * as Schema from "effect/Schema";
var BACKUP_PLUGIN_ID = "backup";
var Frequency = Schema.Literals(["off", "hourly", "daily", "weekly"]);
var TargetKind = Schema.Literals(["none", "google-drive", "s3"]);
var withDefault = (schema, value) => schema.pipe(Schema.withDecodingDefault(Effect.succeed(value)));
var S3Settings = Schema.Struct({
  endpoint: withDefault(Schema.String, ""),
  region: withDefault(Schema.String, "us-east-1"),
  bucket: withDefault(Schema.String, ""),
  prefix: withDefault(Schema.String, ""),
  forcePathStyle: withDefault(Schema.Boolean, false),
  accessKeyId: withDefault(Schema.String, "")
});
var DriveSettings = Schema.Struct({
  clientId: withDefault(Schema.String, ""),
  folderName: withDefault(Schema.String, "p0code backups")
});
var Keep = Schema.Number.check(Schema.isInt(), Schema.isBetween({ minimum: 1, maximum: 1000 }));
var BackupSettings = Schema.Struct({
  target: withDefault(TargetKind, "none"),
  frequency: withDefault(Frequency, "daily"),
  keep: withDefault(Keep, 14),
  s3: withDefault(S3Settings, {}),
  drive: withDefault(DriveSettings, {})
});
var BackupSettingsPatch = Schema.Struct({
  target: Schema.optionalKey(TargetKind),
  frequency: Schema.optionalKey(Frequency),
  keep: Schema.optionalKey(Keep),
  s3: Schema.optionalKey(Schema.Struct({
    endpoint: Schema.optionalKey(Schema.String),
    region: Schema.optionalKey(Schema.String),
    bucket: Schema.optionalKey(Schema.String),
    prefix: Schema.optionalKey(Schema.String),
    forcePathStyle: Schema.optionalKey(Schema.Boolean),
    accessKeyId: Schema.optionalKey(Schema.String),
    secretAccessKey: Schema.optionalKey(Schema.String)
  })),
  drive: Schema.optionalKey(Schema.Struct({
    clientId: Schema.optionalKey(Schema.String),
    clientSecret: Schema.optionalKey(Schema.String),
    folderName: Schema.optionalKey(Schema.String)
  })),
  passphrase: Schema.optionalKey(Schema.String.check(Schema.isMinLength(12)))
});
var ActivityKind = Schema.Literals(["backup", "verify", "restore"]);
var BackupStatus = Schema.Struct({
  settings: BackupSettings,
  stored: Schema.Struct({
    passphrase: Schema.Boolean,
    s3SecretAccessKey: Schema.Boolean,
    driveClientSecret: Schema.Boolean,
    driveSignedIn: Schema.Boolean
  }),
  pendingSignIn: Schema.NullOr(Schema.Struct({ verificationUrl: Schema.String, userCode: Schema.String })),
  signInError: Schema.NullOr(Schema.String),
  activity: Schema.NullOr(Schema.Struct({
    kind: ActivityKind,
    name: Schema.NullOr(Schema.String),
    startedAt: Schema.String
  })),
  lastBackup: Schema.NullOr(Schema.Struct({ name: Schema.String, bytes: Schema.Number, at: Schema.String })),
  lastResult: Schema.NullOr(Schema.Struct({
    kind: ActivityKind,
    ok: Schema.Boolean,
    at: Schema.String,
    message: Schema.String
  })),
  nextRunAt: Schema.NullOr(Schema.String),
  pendingRestore: Schema.NullOr(PendingRestore)
});
var RemoteBackup = Schema.Struct({
  name: Schema.String,
  bytes: Schema.Number,
  createdAt: Schema.String,
  environmentId: Schema.String,
  mine: Schema.Boolean
});
var NoInput = Schema.Struct({});
var BackupRef = Schema.Struct({
  name: Schema.String,
  passphrase: Schema.optionalKey(Schema.String)
});
var backupActions = {
  status: { input: NoInput, output: BackupStatus },
  setSettings: { input: BackupSettingsPatch, output: BackupStatus },
  driveSignIn: { input: NoInput, output: BackupStatus },
  driveSignOut: { input: NoInput, output: BackupStatus },
  backupNow: { input: NoInput, output: BackupStatus },
  list: { input: NoInput, output: Schema.Struct({ backups: Schema.Array(RemoteBackup) }) },
  verify: { input: BackupRef, output: BackupStatus },
  restore: { input: BackupRef, output: BackupStatus },
  cancelRestore: { input: NoInput, output: BackupStatus }
};

// src/backup.ts
import { PluginContext, PluginError as PluginError3 } from "@t3tools/plugin-api";
import * as Clock3 from "effect/Clock";
import * as DateTime3 from "effect/DateTime";
import * as Duration2 from "effect/Duration";
import * as Effect4 from "effect/Effect";
import * as Fiber from "effect/Fiber";
import * as FileSystem5 from "effect/FileSystem";
import * as Option3 from "effect/Option";
import * as Path from "effect/Path";
import * as Queue from "effect/Queue";
import * as Ref from "effect/Ref";
import * as Schema7 from "effect/Schema";
import * as Semaphore from "effect/Semaphore";

// src/archive.ts
import * as NodeFS from "node:fs";
import * as NodeFSP from "node:fs/promises";
import * as NodePath from "node:path";
import { Readable } from "node:stream";
import * as Schema2 from "effect/Schema";

// src/bufferQueue.ts
class BufferQueue {
  pieces = [];
  length = 0;
  push(piece) {
    if (piece.length === 0)
      return;
    this.pieces.push(piece);
    this.length += piece.length;
  }
  take(size) {
    if (size > this.length)
      throw new RangeError(`Asked for ${size} bytes, have ${this.length}.`);
    const out = Buffer.allocUnsafe(size);
    let filled = 0;
    while (filled < size) {
      const piece = this.pieces[0];
      const used = Math.min(piece.length, size - filled);
      piece.copy(out, filled, 0, used);
      filled += used;
      if (used === piece.length)
        this.pieces.shift();
      else
        this.pieces[0] = piece.subarray(used);
    }
    this.length -= size;
    return out;
  }
}

// src/archive.ts
var BLOCK = 512;
var USTAR_MAX_SIZE = 8589934591;
var ZERO_BLOCK = Buffer.alloc(BLOCK);

class ArchiveError extends Schema2.TaggedError()("ArchiveError", {
  detail: Schema2.String
}) {
  get message() {
    return this.detail;
  }
}
function isSafeRelativePath(path) {
  if (path.length === 0 || path.startsWith("/") || path.includes("\\") || path.includes("\x00")) {
    return false;
  }
  return path.split("/").every((part) => part !== "" && part !== "." && part !== "..");
}
function writeOctal(block, offset, width, value) {
  block.write(value.toString(8).padStart(width - 1, "0") + "\x00", offset, width, "ascii");
}
function paxRecord(key, value) {
  const body = ` ${key}=${value}
`;
  let length = Buffer.byteLength(body);
  while (String(length).length + Buffer.byteLength(body) !== length) {
    length = String(length).length + Buffer.byteLength(body);
  }
  return `${length}${body}`;
}
function header(name, size, type, mode) {
  const block = Buffer.alloc(BLOCK);
  block.write(name, 0, 100, "utf8");
  writeOctal(block, 100, 8, mode);
  writeOctal(block, 108, 8, 0);
  writeOctal(block, 116, 8, 0);
  writeOctal(block, 124, 12, size);
  writeOctal(block, 136, 12, 0);
  block.fill(" ", 148, 156);
  block.write(type, 156, 1, "ascii");
  block.write("ustar\x00" + "00", 257, 8, "ascii");
  let sum = 0;
  for (const byte of block)
    sum += byte;
  block.write(sum.toString(8).padStart(6, "0") + "\x00 ", 148, 8, "ascii");
  return block;
}
function padding(size) {
  const rest = size % BLOCK;
  return rest === 0 ? Buffer.alloc(0) : Buffer.alloc(BLOCK - rest);
}
function* entryHeaders(path, size, type) {
  const records = (Buffer.byteLength(path) > 100 ? paxRecord("path", path) : "") + (size > USTAR_MAX_SIZE ? paxRecord("size", String(size)) : "");
  if (records.length > 0) {
    const body = Buffer.from(records, "utf8");
    yield header("PaxHeader", body.length, "x", 420);
    yield body;
    yield padding(body.length);
  }
  yield header(Buffer.byteLength(path) > 100 ? path.slice(-100) : path, size > USTAR_MAX_SIZE ? 0 : size, type, type === "5" ? 493 : 420);
}
function packFiles(root, paths) {
  async function* generate() {
    for (const path of paths) {
      if (!isSafeRelativePath(path))
        throw new ArchiveError({ detail: `Refusing to pack ${path}.` });
      const absolute = NodePath.join(root, ...path.split("/"));
      const info = await NodeFSP.lstat(absolute);
      if (!info.isFile())
        throw new ArchiveError({ detail: `${path} is not a regular file.` });
      yield* entryHeaders(path, info.size, "0");
      let read = 0;
      for await (const chunk of NodeFS.createReadStream(absolute)) {
        read += chunk.length;
        if (read > info.size)
          break;
        yield chunk;
      }
      if (read !== info.size)
        throw new ArchiveError({ detail: `${path} changed while it was archived.` });
      yield padding(info.size);
    }
    yield ZERO_BLOCK;
    yield ZERO_BLOCK;
  }
  return Readable.from(generate(), { objectMode: false });
}
function readString(block, offset, width) {
  const field = block.subarray(offset, offset + width);
  const end = field.indexOf(0);
  return field.subarray(0, end === -1 ? width : end).toString("utf8");
}
function readOctal(block, offset, width) {
  const text = readString(block, offset, width).trim();
  if (!/^[0-7]*$/.test(text))
    throw new ArchiveError({ detail: "The archive has a malformed header." });
  return text === "" ? 0 : Number.parseInt(text, 8);
}
function checksumMatches(block) {
  let sum = 0;
  for (let index = 0;index < BLOCK; index++) {
    sum += index >= 148 && index < 156 ? 32 : block[index];
  }
  return sum === readOctal(block, 148, 8);
}
function parsePax(body) {
  const records = new Map;
  let offset = 0;
  while (offset < body.length) {
    const space = body.indexOf(32, offset);
    const length = Number.parseInt(body.subarray(offset, space).toString("ascii"), 10);
    if (space === -1 || !Number.isSafeInteger(length) || length <= 0) {
      throw new ArchiveError({ detail: "The archive has a malformed extended header." });
    }
    const record = body.subarray(space + 1, offset + length - 1).toString("utf8");
    const equals = record.indexOf("=");
    records.set(record.slice(0, equals), record.slice(equals + 1));
    offset += length;
  }
  return records;
}
async function unpackTo(source, root) {
  const queue = new BufferQueue;
  const iterator = source[Symbol.asyncIterator]();
  const fill = async (size) => {
    while (queue.length < size) {
      const next = await iterator.next();
      if (next.done)
        throw new ArchiveError({ detail: "The archive ended early." });
      queue.push(next.value);
    }
  };
  const take = async (size) => {
    await fill(size);
    return queue.take(size);
  };
  const written = [];
  let pax = new Map;
  while (true) {
    const block = await take(BLOCK);
    if (block.equals(ZERO_BLOCK)) {
      await take(BLOCK);
      return written;
    }
    if (!checksumMatches(block))
      throw new ArchiveError({ detail: "The archive has a damaged header." });
    const type = String.fromCharCode(block[156]);
    const size = Number(pax.get("size") ?? readOctal(block, 124, 12));
    if (!Number.isSafeInteger(size) || size < 0)
      throw new ArchiveError({ detail: "Bad entry size." });
    const prefix = readString(block, 345, 155);
    const path = pax.get("path") ?? (prefix ? `${prefix}/` : "") + readString(block, 0, 100);
    const padded = size + padding(size).length;
    if (type === "x") {
      pax = parsePax((await take(padded)).subarray(0, size));
      continue;
    }
    pax = new Map;
    const cleanPath = path.replace(/\/$/, "");
    if (!isSafeRelativePath(cleanPath))
      throw new ArchiveError({ detail: `Unsafe path ${path} in archive.` });
    const absolute = NodePath.join(root, ...cleanPath.split("/"));
    if (type === "5") {
      await NodeFSP.mkdir(absolute, { recursive: true });
      await take(padded);
      continue;
    }
    if (type !== "0" && type !== "\x00") {
      throw new ArchiveError({ detail: `Unsupported entry type for ${path}.` });
    }
    await NodeFSP.mkdir(NodePath.dirname(absolute), { recursive: true });
    const file = await NodeFSP.open(absolute, "wx", 384);
    try {
      let left = size;
      while (left > 0) {
        if (queue.length === 0)
          await fill(1);
        const piece = queue.take(Math.min(left, queue.length));
        await file.write(piece);
        left -= piece.length;
      }
    } finally {
      await file.close();
    }
    await take(padded - size);
    written.push(cleanPath);
  }
}

// src/backups.ts
import * as DateTime from "effect/DateTime";
import * as Option from "effect/Option";
var BACKUP_SUFFIX = ".p0bak";
var NAME = /^p0code-([A-Za-z0-9-]{1,64})-(\d{8}T\d{6}Z)\.p0bak$/;
var stamp = (epochMs) => DateTime.formatIso(DateTime.makeUnsafe(epochMs)).replace(/[-:]/g, "").replace(/\.\d{3}/, "");
var nameId = (environmentId) => environmentId.replace(/[^A-Za-z0-9-]/g, "").slice(0, 64) || "unknown";
function backupName(environmentId, createdAt) {
  return `p0code-${nameId(environmentId)}-${stamp(createdAt)}${BACKUP_SUFFIX}`;
}
function parseBackupName(name) {
  const match2 = NAME.exec(name);
  if (match2 === null)
    return null;
  const [, environmentId, raw] = match2;
  const iso = `${raw.slice(0, 4)}-${raw.slice(4, 6)}-${raw.slice(6, 11)}:${raw.slice(11, 13)}:${raw.slice(13, 15)}Z`;
  return Option.match(DateTime.make(iso), {
    onNone: () => null,
    onSome: (date) => ({ environmentId, createdAt: DateTime.toEpochMillis(date) })
  });
}
function selectForDeletion(names, environmentId, keep) {
  const own = nameId(environmentId);
  return names.flatMap((name) => {
    const parsed = parseBackupName(name);
    return parsed?.environmentId === own ? [{ name, at: parsed.createdAt }] : [];
  }).sort((a, b) => b.at - a.at || (a.name < b.name ? 1 : -1)).slice(Math.max(1, Math.floor(keep))).map((entry) => entry.name);
}

// src/crypto.ts
import * as NodeCrypto from "node:crypto";
import { Transform } from "node:stream";
import * as Schema3 from "effect/Schema";
var MAGIC = Buffer.from("P0BAK", "ascii");
var FORMAT_VERSION = 1;
var KDF_SCRYPT = 1;
var SALT_BYTES = 16;
var NONCE_PREFIX_BYTES = 7;
var TAG_BYTES = 16;
var HEADER_BYTES = MAGIC.length + 5 + SALT_BYTES + NONCE_PREFIX_BYTES + 4;
var DEFAULT_CHUNK_BYTES = 1024 * 1024;
var MAX_CHUNK_BYTES = 64 * 1024 * 1024;
var MAX_CHUNKS = 2 ** 32;
var DEFAULT_SCRYPT = { log2N: 17, r: 8, p: 1 };
var SCRYPT_LIMITS = { log2N: 20, r: 16, p: 4 };
var DecryptFailure = Schema3.Literals([
  "not-a-backup",
  "unsupported-version",
  "unsafe-parameters",
  "wrong-passphrase-or-damaged",
  "damaged",
  "truncated"
]);
var FAILURE_MESSAGES = {
  "not-a-backup": "This file is not a p0code backup.",
  "unsupported-version": "This backup was made by a newer version of the plugin.",
  "unsafe-parameters": "This backup asks for unsafe decryption parameters.",
  "wrong-passphrase-or-damaged": "Wrong passphrase, or the backup is damaged.",
  damaged: "The backup is damaged or was changed after it was made.",
  truncated: "The backup is incomplete."
};

class BackupDecryptError extends Schema3.TaggedError()("BackupDecryptError", { reason: DecryptFailure }) {
  get message() {
    return FAILURE_MESSAGES[this.reason];
  }
}
function encodeHeader(scrypt2, chunkBytes) {
  const salt = NodeCrypto.randomBytes(SALT_BYTES);
  const noncePrefix = NodeCrypto.randomBytes(NONCE_PREFIX_BYTES);
  const bytes = Buffer.alloc(HEADER_BYTES);
  MAGIC.copy(bytes, 0);
  bytes.writeUInt8(FORMAT_VERSION, 5);
  bytes.writeUInt8(KDF_SCRYPT, 6);
  bytes.writeUInt8(scrypt2.log2N, 7);
  bytes.writeUInt8(scrypt2.r, 8);
  bytes.writeUInt8(scrypt2.p, 9);
  salt.copy(bytes, 10);
  noncePrefix.copy(bytes, 26);
  bytes.writeUInt32BE(chunkBytes, 33);
  return { bytes, scrypt: scrypt2, salt, noncePrefix, chunkBytes };
}
function decodeHeader(bytes) {
  if (!bytes.subarray(0, MAGIC.length).equals(MAGIC))
    throw new BackupDecryptError({ reason: "not-a-backup" });
  if (bytes.readUInt8(5) !== FORMAT_VERSION || bytes.readUInt8(6) !== KDF_SCRYPT) {
    throw new BackupDecryptError({ reason: "unsupported-version" });
  }
  const scrypt2 = { log2N: bytes.readUInt8(7), r: bytes.readUInt8(8), p: bytes.readUInt8(9) };
  const chunkBytes = bytes.readUInt32BE(33);
  if (scrypt2.log2N < 1 || scrypt2.log2N > SCRYPT_LIMITS.log2N || scrypt2.r < 1 || scrypt2.r > SCRYPT_LIMITS.r || scrypt2.p < 1 || scrypt2.p > SCRYPT_LIMITS.p || chunkBytes < 1 || chunkBytes > MAX_CHUNK_BYTES) {
    throw new BackupDecryptError({ reason: "unsafe-parameters" });
  }
  return {
    bytes,
    scrypt: scrypt2,
    salt: bytes.subarray(10, 26),
    noncePrefix: bytes.subarray(26, 33),
    chunkBytes
  };
}
function deriveKey(passphrase, salt, params) {
  const N = 2 ** params.log2N;
  return new Promise((resolve, reject) => {
    NodeCrypto.scrypt(Buffer.from(passphrase.normalize("NFC"), "utf8"), salt, 32, { N, r: params.r, p: params.p, maxmem: 256 * N * params.r + 1024 * 1024 }, (error, key) => error ? reject(error) : resolve(key));
  });
}
function nonce(prefix, index, last) {
  if (index >= MAX_CHUNKS)
    throw new RangeError("Too many chunks for one backup.");
  const out = Buffer.alloc(12);
  prefix.copy(out, 0);
  out.writeUInt32BE(index, NONCE_PREFIX_BYTES);
  out.writeUInt8(last ? 1 : 0, 11);
  return out;
}

class Encryptor extends Transform {
  queue = new BufferQueue;
  index = 0;
  headerSent = false;
  key;
  header;
  constructor(key, header2) {
    super();
    this.key = key;
    this.header = header2;
  }
  seal(plaintext, last) {
    if (!this.headerSent) {
      this.push(this.header.bytes);
      this.headerSent = true;
    }
    const cipher = NodeCrypto.createCipheriv("aes-256-gcm", this.key, nonce(this.header.noncePrefix, this.index++, last));
    cipher.setAAD(this.header.bytes);
    this.push(Buffer.concat([cipher.update(plaintext), cipher.final(), cipher.getAuthTag()]));
  }
  _transform(chunk, _encoding, done) {
    try {
      this.queue.push(chunk);
      while (this.queue.length > this.header.chunkBytes) {
        this.seal(this.queue.take(this.header.chunkBytes), false);
      }
      done();
    } catch (error) {
      done(error);
    }
  }
  _flush(done) {
    try {
      this.seal(this.queue.take(this.queue.length), true);
      done();
    } catch (error) {
      done(error);
    }
  }
}
async function createEncryptStream(passphrase, options = {}) {
  const chunkBytes = options.chunkBytes ?? DEFAULT_CHUNK_BYTES;
  if (chunkBytes < 1 || chunkBytes > MAX_CHUNK_BYTES)
    throw new RangeError("Bad chunk size.");
  const header2 = encodeHeader(options.scrypt ?? DEFAULT_SCRYPT, chunkBytes);
  return new Encryptor(await deriveKey(passphrase, header2.salt, header2.scrypt), header2);
}

class Decryptor extends Transform {
  queue = new BufferQueue;
  header = null;
  key = null;
  index = 0;
  passphrase;
  constructor(passphrase) {
    super();
    this.passphrase = passphrase;
  }
  open(ciphertext, last) {
    const { header: header2, key } = this;
    if (header2 === null || key === null)
      throw new Error("Decryptor used before its key.");
    const decipher = NodeCrypto.createDecipheriv("aes-256-gcm", key, nonce(header2.noncePrefix, this.index, last));
    decipher.setAAD(header2.bytes);
    decipher.setAuthTag(ciphertext.subarray(ciphertext.length - TAG_BYTES));
    try {
      const plaintext = Buffer.concat([
        decipher.update(ciphertext.subarray(0, ciphertext.length - TAG_BYTES)),
        decipher.final()
      ]);
      this.index++;
      this.push(plaintext);
    } catch {
      throw new BackupDecryptError({
        reason: this.index === 0 ? "wrong-passphrase-or-damaged" : "damaged"
      });
    }
  }
  drain() {
    const frame = this.header.chunkBytes + TAG_BYTES;
    while (this.queue.length > frame)
      this.open(this.queue.take(frame), false);
  }
  _transform(chunk, _encoding, done) {
    this.queue.push(chunk);
    if (this.key !== null) {
      try {
        this.drain();
        done();
      } catch (error) {
        done(error);
      }
      return;
    }
    if (this.queue.length < HEADER_BYTES)
      return done();
    let header2;
    try {
      header2 = decodeHeader(this.queue.take(HEADER_BYTES));
    } catch (error) {
      return done(error);
    }
    this.header = header2;
    deriveKey(this.passphrase, header2.salt, header2.scrypt).then((key) => {
      this.key = key;
      try {
        this.drain();
        done();
      } catch (error) {
        done(error);
      }
    }, (error) => done(error));
  }
  _flush(done) {
    try {
      if (this.header === null || this.queue.length < TAG_BYTES) {
        throw new BackupDecryptError({
          reason: this.header === null ? "not-a-backup" : "truncated"
        });
      }
      this.open(this.queue.take(this.queue.length), true);
      done();
    } catch (error) {
      done(error);
    }
  }
}
function createDecryptStream(passphrase) {
  return new Decryptor(passphrase);
}
function createDigestStream() {
  const hash = NodeCrypto.createHash("sha256");
  let bytes = 0;
  let digest = null;
  const stream = new Transform({
    transform(chunk, _encoding, done) {
      hash.update(chunk);
      bytes += chunk.length;
      done(null, chunk);
    }
  });
  return Object.assign(stream, {
    result: () => {
      digest ??= hash.digest("hex");
      return { bytes, sha256: digest };
    }
  });
}

// src/drive.ts
import { PluginError } from "@t3tools/plugin-api";
import * as Clock from "effect/Clock";
import * as Duration from "effect/Duration";
import * as Effect2 from "effect/Effect";
import * as FileSystem from "effect/FileSystem";
import * as HttpClient from "effect/http/HttpClient";
import * as HttpClientRequest from "effect/http/HttpClientRequest";
import * as HttpClientResponse from "effect/http/HttpClientResponse";
import * as Option2 from "effect/Option";
import * as Schema4 from "effect/Schema";
import * as Stream from "effect/Stream";
var DRIVE_SCOPE = "https://www.googleapis.com/auth/drive.file";
var DEVICE_CODE_URL = "https://oauth2.googleapis.com/device/code";
var TOKEN_URL = "https://oauth2.googleapis.com/token";
var REVOKE_URL = "https://oauth2.googleapis.com/revoke";
var FILES_URL = "https://www.googleapis.com/drive/v3/files";
var UPLOAD_URL = "https://www.googleapis.com/upload/drive/v3/files";
var FOLDER_MIME = "application/vnd.google-apps.folder";
var DEVICE_CODE_GRANT = "urn:ietf:params:oauth:grant-type:device_code";
var REQUEST_TIMEOUT = Duration.seconds(20);
var REFRESH_EARLY_MS = 5 * 60000;
var DriveToken = Schema4.Struct({
  accessToken: Schema4.String,
  refreshToken: Schema4.String,
  expiresAtEpochMs: Schema4.Number
});
var TokenResponse = Schema4.Struct({
  access_token: Schema4.String,
  refresh_token: Schema4.optional(Schema4.String),
  expires_in: Schema4.Number
});
var ErrorResponse = Schema4.Struct({ error: Schema4.String });
var DeviceCodeResponse = Schema4.Struct({
  device_code: Schema4.String,
  user_code: Schema4.String,
  verification_url: Schema4.String,
  expires_in: Schema4.Number,
  interval: Schema4.optional(Schema4.Number)
});
var FileList = Schema4.Struct({
  files: Schema4.Array(Schema4.Struct({ id: Schema4.String, name: Schema4.String, size: Schema4.optional(Schema4.String) })),
  nextPageToken: Schema4.optional(Schema4.String)
});
var CreatedFile = Schema4.Struct({ id: Schema4.String, size: Schema4.optional(Schema4.String) });
var isPluginError = Schema4.is(PluginError);
var wrap = (message) => (cause) => isPluginError(cause) ? cause : new PluginError({ message, cause });
var driveQueryString = (value) => `'${value.replaceAll("\\", "\\\\").replaceAll("'", "\\'")}'`;
var postForm = (url, params) => HttpClient.HttpClient.pipe(Effect2.flatMap((client) => client.execute(HttpClientRequest.post(url).pipe(HttpClientRequest.bodyUrlParams(params)))), Effect2.timeout(REQUEST_TIMEOUT));
var toToken = (body, previous) => Clock.currentTimeMillis.pipe(Effect2.map((now) => ({
  accessToken: body.access_token,
  refreshToken: body.refresh_token ?? previous?.refreshToken ?? "",
  expiresAtEpochMs: now + body.expires_in * 1000
})));
var startDeviceAuthorization = Effect2.fn("backup.drive.startDevice")(function* (client) {
  const response = yield* postForm(DEVICE_CODE_URL, {
    client_id: client.clientId,
    scope: DRIVE_SCOPE
  });
  if (response.status >= 400) {
    const failure = yield* HttpClientResponse.schemaBodyJson(ErrorResponse)(response).pipe(Effect2.option);
    return yield* new PluginError({
      message: Option2.match(failure, {
        onNone: () => `Google refused the sign-in (${response.status}).`,
        onSome: ({ error }) => error === "invalid_client" ? 'Google does not know this client ID. Use a client of type "TVs and Limited Input devices".' : `Google refused the sign-in (${error}).`
      })
    });
  }
  const body = yield* HttpClientResponse.schemaBodyJson(DeviceCodeResponse)(response);
  return {
    deviceCode: body.device_code,
    userCode: body.user_code,
    verificationUrl: body.verification_url,
    expiresIn: Duration.seconds(body.expires_in),
    interval: Duration.seconds(body.interval ?? 5)
  };
}, Effect2.mapError(wrap("Could not reach Google sign-in.")));
var pollDeviceToken = Effect2.fn("backup.drive.pollDevice")(function* (client, authorization) {
  let interval = authorization.interval;
  while (true) {
    yield* Effect2.sleep(interval);
    const response = yield* postForm(TOKEN_URL, {
      client_id: client.clientId,
      client_secret: client.clientSecret,
      device_code: authorization.deviceCode,
      grant_type: DEVICE_CODE_GRANT
    }).pipe(Effect2.option);
    if (Option2.isNone(response) || response.value.status >= 500) {
      interval = Duration.sum(interval, Duration.seconds(5));
      continue;
    }
    if (response.value.status < 300) {
      const body = yield* HttpClientResponse.schemaBodyJson(TokenResponse)(response.value);
      if (body.refresh_token === undefined) {
        return yield* new PluginError({ message: "Google did not grant offline access." });
      }
      return yield* toToken(body);
    }
    const failure = yield* HttpClientResponse.schemaBodyJson(ErrorResponse)(response.value);
    if (failure.error === "authorization_pending")
      continue;
    if (failure.error === "slow_down") {
      interval = Duration.sum(interval, Duration.seconds(5));
      continue;
    }
    return yield* new PluginError({
      message: failure.error === "access_denied" ? "Sign-in was denied." : failure.error === "expired_token" ? "The sign-in code expired." : failure.error === "invalid_client" ? "Google rejected the client secret." : `Sign-in failed (${failure.error}).`
    });
  }
}, (effect, _client, authorization) => effect.pipe(Effect2.timeoutOrElse({
  duration: authorization.expiresIn,
  orElse: () => Effect2.fail(new PluginError({ message: "The sign-in code expired." }))
})), Effect2.mapError(wrap("Could not finish Google sign-in.")));
var refreshIfNeeded = Effect2.fn("backup.drive.refresh")(function* (client, token) {
  const now = yield* Clock.currentTimeMillis;
  if (token.expiresAtEpochMs - REFRESH_EARLY_MS > now)
    return Option2.some(token);
  const response = yield* postForm(TOKEN_URL, {
    client_id: client.clientId,
    client_secret: client.clientSecret,
    refresh_token: token.refreshToken,
    grant_type: "refresh_token"
  }).pipe(Effect2.mapError(wrap("Could not reach Google sign-in.")));
  if (response.status >= 400 && response.status < 500 && response.status !== 429) {
    return Option2.none();
  }
  const body = yield* HttpClientResponse.filterStatusOk(response).pipe(Effect2.flatMap(HttpClientResponse.schemaBodyJson(TokenResponse)), Effect2.mapError(wrap("Could not refresh the Google sign-in.")));
  return Option2.some(yield* toToken(body, token));
});
var revokeToken = (token) => postForm(REVOKE_URL, { token: token.refreshToken }).pipe(Effect2.ignore);
var makeDriveRemote = Effect2.fn("backup.drive.make")(function* (options) {
  const client = yield* HttpClient.HttpClient;
  const fs = yield* FileSystem.FileSystem;
  const authorized = (request) => options.accessToken.pipe(Effect2.flatMap((token) => client.execute(HttpClientRequest.bearerToken(request, token))), Effect2.filterOrElse((response) => response.status < 300, (response) => response.text.pipe(Effect2.orElseSucceed(() => ""), Effect2.flatMap((body) => Effect2.fail(new PluginError({
    message: `Google Drive answered ${response.status}${body.includes("storageQuotaExceeded") ? ": the Drive is full" : ""}.`
  }))))));
  const json = (schema) => HttpClientResponse.schemaBodyJson(schema);
  const folderId = Effect2.gen(function* () {
    const query = `mimeType = '${FOLDER_MIME}' and name = ${driveQueryString(options.folderName)} and trashed = false`;
    const found = yield* authorized(HttpClientRequest.get(FILES_URL).pipe(HttpClientRequest.setUrlParams({ q: query, fields: "files(id,name)", spaces: "drive" }))).pipe(Effect2.flatMap(json(FileList)));
    const existing = found.files[0];
    if (existing !== undefined)
      return existing.id;
    const created = yield* authorized(HttpClientRequest.post(FILES_URL).pipe(HttpClientRequest.setUrlParams({ fields: "id" }), HttpClientRequest.bodyJsonUnsafe({ name: options.folderName, mimeType: FOLDER_MIME }))).pipe(Effect2.flatMap(json(CreatedFile)));
    return created.id;
  });
  const list = Effect2.gen(function* () {
    const parent = yield* folderId;
    const found = [];
    let pageToken;
    do {
      const page = yield* authorized(HttpClientRequest.get(FILES_URL).pipe(HttpClientRequest.setUrlParams({
        q: `${driveQueryString(parent)} in parents and trashed = false`,
        fields: "nextPageToken,files(id,name,size)",
        pageSize: "1000",
        ...pageToken === undefined ? {} : { pageToken }
      }))).pipe(Effect2.flatMap(json(FileList)));
      for (const file of page.files) {
        if (file.name.endsWith(BACKUP_SUFFIX) && parseBackupName(file.name) !== null) {
          found.push({ id: file.id, name: file.name, bytes: Number(file.size ?? 0) });
        }
      }
      pageToken = page.nextPageToken;
    } while (pageToken !== undefined);
    return found;
  }).pipe(Effect2.mapError(wrap("Could not list backups in Google Drive.")));
  const upload = Effect2.fn("backup.drive.upload")(function* (name, file) {
    const parent = yield* folderId;
    const session = yield* authorized(HttpClientRequest.post(UPLOAD_URL).pipe(HttpClientRequest.setUrlParams({ uploadType: "resumable" }), HttpClientRequest.setHeaders({
      "X-Upload-Content-Type": "application/octet-stream",
      "X-Upload-Content-Length": String(file.bytes)
    }), HttpClientRequest.bodyJsonUnsafe({ name, parents: [parent] })));
    const location = session.headers["location"];
    if (location === undefined) {
      return yield* new PluginError({ message: "Google Drive did not start the upload." });
    }
    const put2 = yield* HttpClientRequest.bodyFile(file.path, {
      contentType: "application/octet-stream"
    })(HttpClientRequest.put(location).pipe(HttpClientRequest.setUrlParams({ fields: "id,size" }))).pipe(Effect2.provideService(FileSystem.FileSystem, fs));
    const created = yield* authorized(put2).pipe(Effect2.flatMap(json(CreatedFile)));
    if (Number(created.size) !== file.bytes) {
      return yield* new PluginError({ message: "Google Drive stored a different size." });
    }
  }, Effect2.mapError(wrap("Could not upload the backup to Google Drive.")));
  return {
    list,
    upload,
    download: (object, destination) => authorized(HttpClientRequest.get(`${FILES_URL}/${encodeURIComponent(object.id)}`).pipe(HttpClientRequest.setUrlParams({ alt: "media" }))).pipe(Effect2.flatMap((response) => Stream.run(response.stream, fs.sink(destination))), Effect2.mapError(wrap("Could not download the backup from Google Drive."))),
    remove: (object) => authorized(HttpClientRequest.delete(`${FILES_URL}/${encodeURIComponent(object.id)}`)).pipe(Effect2.asVoid, Effect2.mapError(wrap("Could not delete an old backup from Google Drive.")))
  };
});

// src/pipeline.ts
import * as NodeFS3 from "node:fs";
import * as NodeFSP3 from "node:fs/promises";
import { pipeline as pipeline2 } from "node:stream/promises";
import * as NodeZlib from "node:zlib";

// src/snapshot.ts
import * as NodeCrypto2 from "node:crypto";
import * as NodeFS2 from "node:fs";
import * as NodeFSP2 from "node:fs/promises";
import * as NodePath2 from "node:path";
import { pipeline } from "node:stream/promises";
import { DataSnapshotManifest } from "@t3tools/plugin-api";
import * as Schema5 from "effect/Schema";
var MANIFEST_FILE = "manifest.json";
var decodeManifest = Schema5.decodeUnknownSync(Schema5.fromJsonString(DataSnapshotManifest));

class SnapshotError extends Schema5.TaggedError()("SnapshotError", {
  detail: Schema5.String,
  cause: Schema5.optional(Schema5.Defect())
}) {
  get message() {
    return this.detail;
  }
}
var archivedPaths = (manifest) => [
  MANIFEST_FILE,
  ...manifest.files.map((file) => file.path)
];
async function sha256File(path) {
  const hash = NodeCrypto2.createHash("sha256");
  await pipeline(NodeFS2.createReadStream(path), hash);
  return hash.digest("hex");
}
async function listFiles(root, prefix = "") {
  const out = [];
  for (const entry of await NodeFSP2.readdir(NodePath2.join(root, prefix), { withFileTypes: true })) {
    const relative = prefix ? `${prefix}/${entry.name}` : entry.name;
    if (entry.isDirectory())
      out.push(...await listFiles(root, relative));
    else
      out.push(relative);
  }
  return out;
}
async function verifySnapshot(directory) {
  let manifest;
  try {
    manifest = decodeManifest(await NodeFSP2.readFile(NodePath2.join(directory, MANIFEST_FILE), "utf8"));
  } catch (cause) {
    throw new SnapshotError({ detail: "The backup has no readable manifest.", cause });
  }
  if (!manifest.files.some((file) => file.path === "statev2.sqlite")) {
    throw new SnapshotError({ detail: "The backup has no database." });
  }
  const listed = new Set(archivedPaths(manifest));
  for (const path of await listFiles(directory)) {
    if (!listed.has(path))
      throw new SnapshotError({ detail: `The backup has an unlisted file: ${path}.` });
  }
  for (const file of manifest.files) {
    if (!isSafeRelativePath(file.path))
      throw new SnapshotError({ detail: `Unsafe path ${file.path}.` });
    const absolute = NodePath2.join(directory, ...file.path.split("/"));
    const info = await NodeFSP2.stat(absolute).catch(() => null);
    if (info === null || info.size !== file.bytes || await sha256File(absolute) !== file.sha256) {
      throw new SnapshotError({ detail: `${file.path} does not match the manifest.` });
    }
  }
  return manifest;
}

// src/pipeline.ts
async function sealSnapshot(input) {
  const digest = createDigestStream();
  await pipeline2(packFiles(input.directory, archivedPaths(input.manifest)), NodeZlib.createGzip(), await createEncryptStream(input.passphrase, input.encryption), digest, NodeFS3.createWriteStream(input.destination, { flags: "wx", mode: 384 }));
  return digest.result();
}
async function openBackup(input) {
  await NodeFSP3.mkdir(input.directory, { mode: 448 });
  await pipeline2(NodeFS3.createReadStream(input.file), createDecryptStream(input.passphrase), NodeZlib.createGunzip(), async (source) => {
    await unpackTo(source, input.directory);
    for await (const _ of source)
      ;
  });
  return verifySnapshot(input.directory);
}

// src/s3.ts
import { PluginError as PluginError2 } from "@t3tools/plugin-api";
import * as Clock2 from "effect/Clock";
import * as Effect3 from "effect/Effect";
import * as FileSystem3 from "effect/FileSystem";
import * as HttpClient3 from "effect/http/HttpClient";
import * as HttpClientRequest2 from "effect/http/HttpClientRequest";
import * as Schema6 from "effect/Schema";
import * as Stream2 from "effect/Stream";

// src/sigv4.ts
import * as NodeCrypto3 from "node:crypto";
import * as DateTime2 from "effect/DateTime";
var EMPTY_PAYLOAD_SHA256 = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";
var sha256Hex = (data) => NodeCrypto3.createHash("sha256").update(data).digest("hex");
var hmac = (key, data) => NodeCrypto3.createHmac("sha256", key).update(data).digest();
function uriEncode(value) {
  return encodeURIComponent(value).replace(/[!'()*]/g, (character) => `%${character.charCodeAt(0).toString(16).toUpperCase()}`);
}
function canonicalPath(url) {
  const path = url.pathname === "" ? "/" : url.pathname;
  return path.split("/").map((segment) => uriEncode(decodeURIComponent(segment))).join("/");
}
function canonicalQuery(url) {
  return [...url.searchParams].map(([key, value]) => [uriEncode(key), uriEncode(value)]).sort(([a, aValue], [b, bValue]) => a < b ? -1 : a > b ? 1 : aValue < bValue ? -1 : aValue > bValue ? 1 : 0).map(([key, value]) => `${key}=${value}`).join("&");
}
function amzDate(epochMs) {
  return DateTime2.formatIso(DateTime2.makeUnsafe(epochMs)).replace(/[-:]/g, "").replace(/\.\d{3}/, "");
}
function signingKey(secret, date, region, service) {
  const dateKey = hmac(`AWS4${secret}`, date);
  return hmac(hmac(hmac(dateKey, region), service), "aws4_request");
}
function signV4(input) {
  const timestamp = amzDate(input.now);
  const date = timestamp.slice(0, 8);
  const headers = {};
  for (const [name, value] of Object.entries(input.headers ?? {})) {
    headers[name.toLowerCase()] = value;
  }
  headers.host ??= input.url.host;
  headers["x-amz-date"] = timestamp;
  if (input.credentials.sessionToken !== undefined) {
    headers["x-amz-security-token"] = input.credentials.sessionToken;
  }
  const names = Object.keys(headers).sort();
  const signedHeaders = names.join(";");
  const canonicalHeaders = names.map((name) => `${name}:${headers[name].trim().replace(/\s+/g, " ")}
`).join("");
  const canonicalRequest = [
    input.method.toUpperCase(),
    canonicalPath(input.url),
    canonicalQuery(input.url),
    canonicalHeaders,
    signedHeaders,
    input.payloadHash
  ].join(`
`);
  const scope = `${date}/${input.region}/${input.service}/aws4_request`;
  const stringToSign = ["AWS4-HMAC-SHA256", timestamp, scope, sha256Hex(canonicalRequest)].join(`
`);
  const signature = NodeCrypto3.createHmac("sha256", signingKey(input.credentials.secretAccessKey, date, input.region, input.service)).update(stringToSign).digest("hex");
  headers.authorization = `AWS4-HMAC-SHA256 Credential=${input.credentials.accessKeyId}/${scope}, SignedHeaders=${signedHeaders}, Signature=${signature}`;
  return { headers, canonicalRequest, stringToSign, signature };
}

// src/s3.ts
function objectUrl(config, key) {
  let endpoint;
  try {
    endpoint = new URL(config.endpoint.trim());
  } catch {
    return null;
  }
  if (endpoint.protocol !== "https:" && endpoint.protocol !== "http:")
    return null;
  const encodedKey = key === undefined ? "" : key.split("/").map(uriEncode).join("/");
  const base = endpoint.pathname.replace(/\/+$/, "");
  if (config.forcePathStyle) {
    return new URL(`${endpoint.origin}${base}/${uriEncode(config.bucket)}/${encodedKey}`);
  }
  return new URL(`${endpoint.protocol}//${config.bucket}.${endpoint.host}${base}/${encodedKey}`);
}
var XML_ENTITIES = {
  amp: "&",
  lt: "<",
  gt: ">",
  quot: '"',
  apos: "'"
};
var unescapeXml = (text) => text.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (whole, entity) => {
  if (entity.startsWith("#x") || entity.startsWith("#X")) {
    return String.fromCodePoint(Number.parseInt(entity.slice(2), 16));
  }
  if (entity.startsWith("#"))
    return String.fromCodePoint(Number.parseInt(entity.slice(1), 10));
  return XML_ENTITIES[entity] ?? whole;
});
var tag = (xml, name) => {
  const match3 = new RegExp(`<${name}>([\\s\\S]*?)</${name}>`).exec(xml);
  return match3 === null ? null : unescapeXml(match3[1]);
};
function parseListObjectsV2(xml) {
  const objects = [...xml.matchAll(/<Contents>([\s\S]*?)<\/Contents>/g)].flatMap((match3) => {
    const key = tag(match3[1], "Key");
    const size = Number(tag(match3[1], "Size"));
    return key === null || !Number.isFinite(size) ? [] : [{ key, size }];
  });
  return {
    objects,
    nextContinuationToken: tag(xml, "IsTruncated") === "true" ? tag(xml, "NextContinuationToken") : null
  };
}
function describeS3Error(status, body) {
  const code = tag(body, "Code");
  const message = tag(body, "Message");
  if (code === null)
    return `The storage service answered ${status}.`;
  return `The storage service answered ${status} ${code}${message ? `: ${message}` : ""}.`;
}
function validateS3Config(config) {
  if (objectUrl(config) === null)
    return "Set the S3 endpoint to an http(s) URL.";
  if (config.bucket.trim() === "")
    return "Set the S3 bucket.";
  if (config.region.trim() === "")
    return "Set the S3 region (R2 uses auto).";
  if (config.accessKeyId === "" || config.secretAccessKey === "") {
    return "Set the S3 access key and secret.";
  }
  return null;
}
var makeS3Remote = Effect3.fn("backup.s3.make")(function* (config) {
  const problem = validateS3Config(config);
  if (problem !== null)
    return yield* new PluginError2({ message: problem });
  const client = yield* HttpClient3.HttpClient;
  const fs = yield* FileSystem3.FileSystem;
  const credentials = {
    accessKeyId: config.accessKeyId,
    secretAccessKey: config.secretAccessKey
  };
  const send = Effect3.fn("backup.s3.send")(function* (method, url, options = {}) {
    const payloadHash = options.payloadHash ?? EMPTY_PAYLOAD_SHA256;
    const signed = signV4({
      method,
      url,
      headers: { "x-amz-content-sha256": payloadHash },
      payloadHash,
      region: config.region.trim(),
      service: "s3",
      credentials,
      now: yield* Clock2.currentTimeMillis
    });
    const { host: _host, ...headers } = signed.headers;
    let request = HttpClientRequest2.make(method)(url).pipe(HttpClientRequest2.setHeaders(headers));
    if (options.file !== undefined) {
      request = yield* HttpClientRequest2.bodyFile(options.file, {
        contentType: "application/octet-stream"
      })(request).pipe(Effect3.provideService(FileSystem3.FileSystem, fs));
    }
    const response = yield* client.execute(request);
    if (response.status >= 300) {
      const body = yield* response.text.pipe(Effect3.orElseSucceed(() => ""));
      return yield* new PluginError2({ message: describeS3Error(response.status, body) });
    }
    return response;
  });
  const isPluginError2 = Schema6.is(PluginError2);
  const fail2 = (message) => (cause) => isPluginError2(cause) ? cause : new PluginError2({ message, cause });
  const keyOf = (name) => `${config.prefix}${name}`;
  const list = Effect3.gen(function* () {
    const found = [];
    let token = null;
    do {
      const url = objectUrl(config);
      url.searchParams.set("list-type", "2");
      if (config.prefix !== "")
        url.searchParams.set("prefix", config.prefix);
      if (token !== null)
        url.searchParams.set("continuation-token", token);
      const response = yield* send("GET", url);
      const page = parseListObjectsV2(yield* response.text);
      for (const object of page.objects) {
        const name = object.key.slice(config.prefix.length);
        if (name.endsWith(BACKUP_SUFFIX) && parseBackupName(name) !== null) {
          found.push({ id: object.key, name, bytes: object.size });
        }
      }
      token = page.nextContinuationToken;
    } while (token !== null);
    return found;
  }).pipe(Effect3.mapError(fail2("Could not list backups in the bucket.")));
  return {
    list,
    upload: (name, file) => send("PUT", objectUrl(config, keyOf(name)), {
      payloadHash: file.sha256,
      file: file.path
    }).pipe(Effect3.asVoid, Effect3.mapError(fail2("Could not upload the backup."))),
    download: (object, destination) => send("GET", objectUrl(config, object.id)).pipe(Effect3.flatMap((response) => Stream2.run(response.stream, fs.sink(destination))), Effect3.mapError(fail2("Could not download the backup."))),
    remove: (object) => send("DELETE", objectUrl(config, object.id)).pipe(Effect3.asVoid, Effect3.mapError(fail2("Could not delete an old backup.")))
  };
});

// src/schedule.ts
var HOUR = 60 * 60 * 1000;
var FREQUENCY_MS = {
  hourly: HOUR,
  daily: 24 * HOUR,
  weekly: 7 * 24 * HOUR
};
var FIRST_RETRY_MS = 5 * 60 * 1000;
function nextRunAt(state, now) {
  if (state.frequency === "off")
    return null;
  const interval = FREQUENCY_MS[state.frequency];
  let next = state.lastSuccessAt === null ? now : state.lastSuccessAt + interval;
  if (state.consecutiveFailures > 0 && state.lastAttemptAt !== null) {
    const backoff = Math.min(interval, FIRST_RETRY_MS * 2 ** (state.consecutiveFailures - 1));
    next = Math.max(next, state.lastAttemptAt + backoff);
  }
  return Math.max(now, next);
}

// src/backup.ts
var KEYS = {
  settings: "settings",
  history: "history",
  passphrase: "passphrase",
  s3Secret: "s3-secret-access-key",
  driveSecret: "drive-client-secret",
  driveToken: "drive-token"
};
var History = Schema7.Struct({
  lastSuccessAt: Schema7.NullOr(Schema7.Number),
  lastAttemptAt: Schema7.NullOr(Schema7.Number),
  consecutiveFailures: Schema7.Number,
  lastBackup: Schema7.NullOr(Schema7.Struct({ name: Schema7.String, bytes: Schema7.Number, at: Schema7.String })),
  lastResult: Schema7.NullOr(Schema7.Struct({
    kind: Schema7.Literals(["backup", "verify", "restore"]),
    ok: Schema7.Boolean,
    at: Schema7.String,
    message: Schema7.String
  }))
});
var EMPTY_HISTORY = {
  lastSuccessAt: null,
  lastAttemptAt: null,
  consecutiveFailures: 0,
  lastBackup: null,
  lastResult: null
};
var MAX_SLEEP = Duration2.minutes(5);
var isPluginError2 = Schema7.is(PluginError3);
var toPluginError = (message) => (cause) => isPluginError2(cause) ? cause : new PluginError3({ message, cause });
var isUserFacing = Schema7.is(Schema7.Union([BackupDecryptError, ArchiveError, SnapshotError]));
var fromPromise = (fallback, run3) => Effect4.tryPromise({
  try: run3,
  catch: (cause) => new PluginError3({ message: isUserFacing(cause) ? cause.message : fallback, cause })
});
var iso = (epochMs) => DateTime3.formatIso(DateTime3.makeUnsafe(epochMs));
var megabytes = (bytes) => `${(bytes / 1024 / 1024).toFixed(1)} MB`;
var makeBackupService = Effect4.fn("backup.make")(function* () {
  const ctx = yield* PluginContext;
  const fs = yield* FileSystem5.FileSystem;
  const path = yield* Path.Path;
  const services = yield* Effect4.context();
  const pluginScope = yield* Effect4.scope;
  const state = yield* Ref.make({
    pendingSignIn: null,
    signInError: null,
    activity: null
  });
  const workLock = yield* Semaphore.make(1);
  const wake = yield* Queue.sliding(1);
  let signInFiber = null;
  const workDir = path.join(ctx.dataDir, "work");
  yield* fs.remove(workDir, { recursive: true }).pipe(Effect4.ignore);
  yield* fs.makeDirectory(workDir, { recursive: true, mode: 448 }).pipe(Effect4.mapError(toPluginError("Could not create the backup work folder.")));
  const readJson = (key, schema) => ctx.storage.get(key).pipe(Effect4.map(Option3.flatMap(Schema7.decodeUnknownOption(Schema7.fromJsonString(schema)))));
  const writeJson = (key, schema, value) => Schema7.encodeEffect(Schema7.fromJsonString(schema))(value).pipe(Effect4.mapError(toPluginError("Could not save backup settings.")), Effect4.flatMap((json) => ctx.storage.set(key, json)));
  const secret = (key) => ctx.storage.get(key).pipe(Effect4.map(Option3.filter((value) => value !== "")));
  const readSettings = readJson(KEYS.settings, BackupSettings).pipe(Effect4.flatMap(Option3.match({
    onSome: Effect4.succeed,
    onNone: () => Schema7.decodeEffect(BackupSettings)({}).pipe(Effect4.mapError(toPluginError("Could not read backup settings.")))
  })));
  const readHistory = readJson(KEYS.history, History).pipe(Effect4.map(Option3.getOrElse(() => EMPTY_HISTORY)));
  const updateHistory = (update2) => readHistory.pipe(Effect4.flatMap((history) => writeJson(KEYS.history, History, update2(history))));
  const isConfigured = Effect4.gen(function* () {
    const settings = yield* readSettings;
    if (settings.target === "none" || Option3.isNone(yield* secret(KEYS.passphrase)))
      return false;
    if (settings.target === "s3")
      return Option3.isSome(yield* secret(KEYS.s3Secret));
    return Option3.isSome(yield* secret(KEYS.driveToken));
  });
  const scheduledAt = Effect4.gen(function* () {
    const [settings, history, configured, now] = yield* Effect4.all([
      readSettings,
      readHistory,
      isConfigured,
      Clock3.currentTimeMillis
    ]);
    return configured ? nextRunAt({ ...history, frequency: settings.frequency }, now) : null;
  });
  const status = Effect4.gen(function* () {
    const [settings, history, runtime, next] = yield* Effect4.all([
      readSettings,
      readHistory,
      Ref.get(state),
      scheduledAt
    ]);
    const has = (key) => secret(key).pipe(Effect4.map(Option3.isSome));
    return {
      settings,
      stored: {
        passphrase: yield* has(KEYS.passphrase),
        s3SecretAccessKey: yield* has(KEYS.s3Secret),
        driveClientSecret: yield* has(KEYS.driveSecret),
        driveSignedIn: yield* has(KEYS.driveToken)
      },
      pendingSignIn: runtime.pendingSignIn,
      signInError: runtime.signInError,
      activity: runtime.activity,
      lastBackup: history.lastBackup,
      lastResult: history.lastResult,
      nextRunAt: next === null ? null : iso(next),
      pendingRestore: yield* ctx.dataBackup.pendingRestore.pipe(Effect4.orElseSucceed(() => null))
    };
  });
  const publishStatus = Effect4.gen(function* () {
    const current = yield* status;
    const line = current.activity !== null ? { backup: "Backing up…", verify: "Checking a backup…", restore: "Preparing a restore…" }[current.activity.kind] : current.pendingRestore !== null ? "A restore is waiting for confirmation" : current.lastResult !== null && !current.lastResult.ok ? current.lastResult.message : current.lastBackup !== null ? `Last backup ${current.lastBackup.at}` : current.settings.target === "none" ? "No backup target" : "No backups yet";
    yield* ctx.reportStatus(line);
  }).pipe(Effect4.ignore);
  const setState = (update2) => Ref.update(state, (current) => ({ ...current, ...update2 })).pipe(Effect4.andThen(publishStatus));
  const driveClient = Effect4.gen(function* () {
    const settings = yield* readSettings;
    const clientSecret = yield* secret(KEYS.driveSecret);
    if (settings.drive.clientId.trim() === "" || Option3.isNone(clientSecret)) {
      return yield* new PluginError3({ message: "Set the Google client ID and secret first." });
    }
    return { clientId: settings.drive.clientId.trim(), clientSecret: clientSecret.value };
  });
  const driveAccessToken = Effect4.gen(function* () {
    const stored = yield* readJson(KEYS.driveToken, DriveToken);
    if (Option3.isNone(stored)) {
      return yield* new PluginError3({ message: "Sign in to Google Drive first." });
    }
    const fresh = yield* refreshIfNeeded(yield* driveClient, stored.value);
    if (Option3.isNone(fresh)) {
      yield* ctx.storage.remove(KEYS.driveToken);
      return yield* new PluginError3({ message: "The Google sign-in expired. Sign in again." });
    }
    if (fresh.value !== stored.value)
      yield* writeJson(KEYS.driveToken, DriveToken, fresh.value);
    return fresh.value.accessToken;
  });
  const remote = Effect4.gen(function* () {
    const settings = yield* readSettings;
    if (settings.target === "s3") {
      const secretAccessKey = yield* secret(KEYS.s3Secret);
      return yield* makeS3Remote({
        ...settings.s3,
        secretAccessKey: Option3.getOrElse(secretAccessKey, () => "")
      });
    }
    if (settings.target === "google-drive") {
      return yield* makeDriveRemote({
        folderName: settings.drive.folderName,
        accessToken: driveAccessToken.pipe(Effect4.provideContext(services))
      });
    }
    return yield* new PluginError3({ message: "Choose where backups go first." });
  }).pipe(Effect4.provideContext(services));
  const storedPassphrase = secret(KEYS.passphrase).pipe(Effect4.flatMap(Option3.match({
    onSome: Effect4.succeed,
    onNone: () => Effect4.fail(new PluginError3({ message: "Set a backup passphrase first." }))
  })));
  const backupOnce = Effect4.fn("backup.run")(function* (target, passphrase) {
    const environmentId = yield* ctx.environment.environmentId;
    const now = yield* Clock3.currentTimeMillis;
    const name = backupName(environmentId, now);
    const staged = path.join(workDir, name);
    const sealed = yield* Effect4.scoped(Effect4.gen(function* () {
      const snapshot = yield* ctx.dataBackup.snapshot;
      return yield* fromPromise("Could not encrypt the backup.", () => sealSnapshot({ ...snapshot, destination: staged, passphrase }));
    }));
    yield* target.upload(name, { path: staged, ...sealed }).pipe(Effect4.ensuring(fs.remove(staged).pipe(Effect4.ignore)));
    const settings = yield* readSettings;
    const existing = yield* target.list;
    const expired = new Set(selectForDeletion(existing.map((object) => object.name), environmentId, settings.keep));
    yield* Effect4.forEach(existing.filter((object) => expired.has(object.name)), (object) => target.remove(object).pipe(Effect4.catch((error) => Effect4.logWarning(error.message))), { discard: true });
    const at = iso(now);
    yield* updateHistory((history) => ({
      ...history,
      lastSuccessAt: now,
      lastAttemptAt: now,
      consecutiveFailures: 0,
      lastBackup: { name, bytes: sealed.bytes, at },
      lastResult: {
        kind: "backup",
        ok: true,
        at,
        message: `Backed up ${megabytes(sealed.bytes)}${expired.size > 0 ? `, removed ${expired.size} old` : ""}.`
      }
    }));
  });
  const findRemote = Effect4.fn("backup.find")(function* (target, name) {
    const found = (yield* target.list).find((object) => object.name === name);
    if (found === undefined) {
      return yield* new PluginError3({ message: `No backup named ${name}.` });
    }
    return found;
  });
  const openRemote = Effect4.fn("backup.open")(function* (target, object, passphrase) {
    const file = path.join(workDir, object.name);
    const directory = path.join(workDir, `${object.name}.d`);
    yield* Effect4.addFinalizer(() => Effect4.all([fs.remove(file), fs.remove(directory, { recursive: true })], {
      discard: true
    }).pipe(Effect4.ignore));
    yield* target.download(object, file);
    const manifest = yield* fromPromise("Could not open the backup.", () => openBackup({ file, directory, passphrase }));
    return { directory, manifest };
  });
  const recordResult = (kind, ok, message) => Clock3.currentTimeMillis.pipe(Effect4.flatMap((now) => updateHistory((history) => ({
    ...history,
    ...kind === "backup" && !ok ? { lastAttemptAt: now, consecutiveFailures: history.consecutiveFailures + 1 } : {},
    lastResult: { kind, ok, at: iso(now), message }
  }))));
  const startJob = Effect4.fn("backup.startJob")(function* (kind, name, work) {
    const busy = (yield* Ref.get(state)).activity;
    if (busy !== null) {
      return yield* new PluginError3({ message: "Another backup task is still running." });
    }
    const startedAt = iso(yield* Clock3.currentTimeMillis);
    yield* setState({ activity: { kind, name, startedAt } });
    yield* workLock.withPermits(1)(work).pipe(Effect4.flatMap((message) => typeof message === "string" ? recordResult(kind, true, message) : Effect4.void), Effect4.catch((error) => recordResult(kind, false, error.message)), Effect4.ensuring(setState({ activity: null })), Effect4.ensuring(Queue.offer(wake, undefined)), Effect4.forkIn(pluginScope));
  });
  const backupNow = Effect4.gen(function* () {
    const target = yield* remote;
    const passphrase = yield* storedPassphrase;
    yield* startJob("backup", null, backupOnce(target, passphrase));
    return yield* status;
  });
  const verify = Effect4.fn("backup.verify")(function* (input) {
    const target = yield* remote;
    const passphrase = input.passphrase ?? (yield* storedPassphrase);
    const work = Effect4.scoped(Effect4.gen(function* () {
      const object = yield* findRemote(target, input.name);
      const { manifest } = yield* openRemote(target, object, passphrase);
      return `${input.name} is intact: ${manifest.files.length} files, made ${manifest.createdAt}.`;
    }));
    yield* startJob("verify", input.name, work);
    return yield* status;
  });
  const restore = Effect4.fn("backup.restore")(function* (input) {
    const target = yield* remote;
    const passphrase = input.passphrase ?? (yield* storedPassphrase);
    const work = Effect4.scoped(Effect4.gen(function* () {
      const object = yield* findRemote(target, input.name);
      const { directory } = yield* openRemote(target, object, passphrase);
      yield* ctx.dataBackup.stageRestore(directory);
      return "Ready to restore. p0code asks you to confirm before replacing anything.";
    }));
    yield* startJob("restore", input.name, work);
    return yield* status;
  });
  const list = Effect4.gen(function* () {
    const target = yield* remote;
    const environmentId = yield* ctx.environment.environmentId;
    const own = nameId(environmentId);
    const backups = (yield* target.list).flatMap((object) => {
      const parsed = parseBackupName(object.name);
      if (parsed === null)
        return [];
      return [
        {
          name: object.name,
          bytes: object.bytes,
          createdAt: iso(parsed.createdAt),
          environmentId: parsed.environmentId,
          mine: parsed.environmentId === own
        }
      ];
    });
    return { backups: backups.sort((a, b) => a.createdAt < b.createdAt ? 1 : -1) };
  });
  const setSettings = Effect4.fn("backup.setSettings")(function* (patch) {
    const current = yield* readSettings;
    const { secretAccessKey, ...s3 } = patch.s3 ?? {};
    const { clientSecret, ...drive } = patch.drive ?? {};
    const next = {
      target: patch.target ?? current.target,
      frequency: patch.frequency ?? current.frequency,
      keep: patch.keep ?? current.keep,
      s3: { ...current.s3, ...s3 },
      drive: { ...current.drive, ...drive }
    };
    const putSecret = (key, value) => value === undefined ? Effect4.void : value === "" ? ctx.storage.remove(key) : ctx.storage.set(key, value);
    yield* putSecret(KEYS.s3Secret, secretAccessKey);
    yield* putSecret(KEYS.driveSecret, clientSecret);
    yield* putSecret(KEYS.passphrase, patch.passphrase);
    if (next.drive.clientId !== current.drive.clientId)
      yield* ctx.storage.remove(KEYS.driveToken);
    yield* writeJson(KEYS.settings, BackupSettings, next);
    yield* Queue.offer(wake, undefined);
    yield* publishStatus;
    return yield* status;
  });
  const cancelSignIn = Effect4.gen(function* () {
    const fiber = signInFiber;
    signInFiber = null;
    if (fiber !== null)
      yield* Fiber.interrupt(fiber);
    yield* setState({ pendingSignIn: null });
  });
  const driveSignIn = Effect4.gen(function* () {
    if ((yield* Ref.get(state)).pendingSignIn !== null)
      return yield* status;
    const client = yield* driveClient;
    const authorization = yield* startDeviceAuthorization(client).pipe(Effect4.provideContext(services));
    yield* setState({
      pendingSignIn: {
        verificationUrl: authorization.verificationUrl,
        userCode: authorization.userCode
      },
      signInError: null
    });
    signInFiber = yield* pollDeviceToken(client, authorization).pipe(Effect4.flatMap((token) => writeJson(KEYS.driveToken, DriveToken, token)), Effect4.andThen(Queue.offer(wake, undefined)), Effect4.catch((error) => setState({ signInError: error.message })), Effect4.ensuring(Effect4.suspend(() => {
      signInFiber = null;
      return setState({ pendingSignIn: null });
    })), Effect4.provideContext(services), Effect4.asVoid, Effect4.forkIn(pluginScope));
    return yield* status;
  });
  const driveSignOut = Effect4.gen(function* () {
    yield* cancelSignIn;
    const token = yield* readJson(KEYS.driveToken, DriveToken);
    if (Option3.isSome(token)) {
      yield* revokeToken(token.value).pipe(Effect4.provideContext(services));
    }
    yield* ctx.storage.remove(KEYS.driveToken);
    yield* setState({ signInError: null });
    return yield* status;
  });
  const cancelRestore = Effect4.gen(function* () {
    yield* ctx.dataBackup.cancelRestore;
    yield* publishStatus;
    return yield* status;
  });
  const scheduler = Effect4.gen(function* () {
    const next = yield* scheduledAt;
    if (next === null)
      return yield* Queue.take(wake);
    const wait = Math.max(0, next - (yield* Clock3.currentTimeMillis));
    const delay = Duration2.min(Duration2.millis(wait), MAX_SLEEP);
    const woken = yield* Effect4.race(Effect4.sleep(delay).pipe(Effect4.as(false)), Queue.take(wake).pipe(Effect4.as(true)));
    if (woken || (yield* Clock3.currentTimeMillis) < next)
      return;
    if ((yield* Ref.get(state)).activity !== null)
      return yield* Queue.take(wake);
    yield* Effect4.gen(function* () {
      const target = yield* remote;
      const passphrase = yield* storedPassphrase;
      yield* startJob("backup", null, backupOnce(target, passphrase));
    }).pipe(Effect4.catch((error) => recordResult("backup", false, error.message)));
    yield* Queue.take(wake);
  }).pipe(Effect4.catchCause((cause) => Effect4.logError("Backup scheduler step failed", { cause }).pipe(Effect4.andThen(Effect4.sleep(MAX_SLEEP)))), Effect4.forever);
  yield* scheduler.pipe(Effect4.forkIn(pluginScope));
  yield* publishStatus;
  return {
    status,
    setSettings,
    driveSignIn,
    driveSignOut,
    backupNow,
    list,
    verify,
    restore,
    cancelRestore
  };
});

// src/index.ts
var backupPlugin = definePlugin({
  manifest: {
    id: BACKUP_PLUGIN_ID,
    name: "Backups",
    description: "Backs up your chats, attachments, settings and keybindings to Google Drive or S3-compatible storage, encrypted on this machine with your passphrase.",
    version: "0.1.0",
    unofficial: false,
    externalServices: [
      "Google Drive (oauth2.googleapis.com, www.googleapis.com), when chosen",
      "The S3-compatible endpoint you configure, when chosen"
    ],
    capabilities: ["network:outbound", "data:backup"],
    httpRoutes: []
  },
  actions: backupActions,
  start: Effect5.gen(function* () {
    const service = yield* makeBackupService();
    return {
      actions: {
        status: () => service.status,
        setSettings: service.setSettings,
        driveSignIn: () => service.driveSignIn,
        driveSignOut: () => service.driveSignOut,
        backupNow: () => service.backupNow,
        list: () => service.list,
        verify: service.verify,
        restore: service.restore,
        cancelRestore: () => service.cancelRestore
      }
    };
  })
});
export {
  backupPlugin
};
