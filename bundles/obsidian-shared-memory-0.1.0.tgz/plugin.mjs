// src/index.ts
import { definePlugin } from "@t3tools/plugin-api";
import * as Effect4 from "effect/Effect";

// src/actions.ts
import * as Schema from "effect/Schema";
var OBSIDIAN_SHARED_MEMORY_ID = "obsidian-shared-memory";
var SharedMemoryStatus = Schema.Struct({
  connected: Schema.Boolean,
  phase: Schema.Literals(["idle", "syncing", "error"]),
  folder: Schema.String,
  vault: Schema.String,
  agentId: Schema.String,
  enabled: Schema.Boolean,
  paused: Schema.Boolean,
  lastSyncedAt: Schema.NullOr(Schema.String),
  lastError: Schema.NullOr(Schema.String),
  snippet: Schema.String
});
var Vault = Schema.Struct({ id: Schema.String, name: Schema.String, region: Schema.String });
var SharedMemoryVaults = Schema.Struct({
  vaults: Schema.Array(Vault),
  shared: Schema.Array(Vault)
});
var SharedMemoryCommand = Schema.Union([
  Schema.Struct({
    action: Schema.Literal("login"),
    email: Schema.String,
    password: Schema.String,
    mfa: Schema.optional(Schema.String)
  }),
  Schema.Struct({
    action: Schema.Literal("configure"),
    vault: Schema.String,
    folder: Schema.String,
    password: Schema.optional(Schema.String)
  }),
  Schema.Struct({
    action: Schema.Literal("preferences"),
    enabled: Schema.Boolean,
    agentId: Schema.String
  }),
  Schema.Struct({ action: Schema.Literals(["pause", "resume", "logout"]) })
]);
var NoInput = Schema.Struct({});
var sharedMemoryActions = {
  status: { input: NoInput, output: SharedMemoryStatus },
  vaults: { input: NoInput, output: SharedMemoryVaults },
  command: { input: SharedMemoryCommand, output: SharedMemoryStatus }
};

// src/sync.ts
import { PluginContext, PluginError } from "@t3tools/plugin-api";

// ../../packages/shared/src/HostProcess.ts
import * as Context from "effect/Context";
import * as Effect from "effect/Effect";
import * as Schema2 from "effect/Schema";
import * as NodeDns from "node:dns";
import * as NodeOS from "node:os";
import * as NodeSea from "node:sea";
var Platform = Context.Reference("@t3tools/shared/HostProcess/Platform", {
  defaultValue: () => process.platform
});
var Architecture = Context.Reference("@t3tools/shared/HostProcess/Architecture", {
  defaultValue: () => process.arch
});
var KernelRelease = Context.Reference("@t3tools/shared/HostProcess/KernelRelease", {
  defaultValue: () => NodeOS.release()
});
var LinuxLibc = Context.Reference("@t3tools/shared/HostProcess/LinuxLibc", {
  defaultValue: () => {
    try {
      const report = process.report?.getReport();
      return typeof report?.header?.glibcVersionRuntime === "string" ? "gnu" : "musl";
    } catch {
      return "musl";
    }
  }
});
var Hostname = Context.Reference("@t3tools/shared/HostProcess/Hostname", {
  defaultValue: () => NodeOS.hostname()
});
var Username = Context.Reference("@t3tools/shared/HostProcess/Username", {
  defaultValue: () => {
    try {
      return NodeOS.userInfo().username.trim() || null;
    } catch {
      return null;
    }
  }
});
var HomeDirectory = Context.Reference("@t3tools/shared/HostProcess/HomeDirectory", {
  defaultValue: () => NodeOS.homedir()
});
var Environment = Context.Reference("@t3tools/shared/HostProcess/Environment", {
  defaultValue: () => process.env
});
var WorkingDirectory = Context.Reference("@t3tools/shared/HostProcess/WorkingDirectory", {
  defaultValue: () => process.cwd()
});
var ExecutablePath = Context.Reference("@t3tools/shared/HostProcess/ExecutablePath", {
  defaultValue: () => process.execPath
});
var Arguments = Context.Reference("@t3tools/shared/HostProcess/Arguments", {
  defaultValue: () => process.argv
});
var InvokedAs = Context.Reference("@t3tools/shared/HostProcess/InvokedAs", {
  defaultValue: () => process.argv0
});
var IsExecutable = Context.Reference("@t3tools/shared/HostProcess/IsExecutable", {
  defaultValue: () => NodeSea.isSea()
});

class HostnameLookupError extends Schema2.TaggedError()("HostnameLookupError", { hostname: Schema2.String, cause: Schema2.Defect() }) {
  get message() {
    return `Could not resolve ${this.hostname}.`;
  }
}
var Addresses = Context.Reference("@t3tools/shared/HostProcess/Addresses", {
  defaultValue: Effect.fnUntraced(function* () {
    const interfaces = Object.values(NodeOS.networkInterfaces()).flat().flatMap((entry) => entry ? [entry.address] : []);
    const hostname2 = NodeOS.hostname();
    const resolved = yield* Effect.tryPromise({
      try: () => NodeDns.promises.lookup(hostname2, { all: true }),
      catch: (cause) => new HostnameLookupError({ hostname: hostname2, cause })
    }).pipe(Effect.map((entries) => entries.map((entry) => entry.address)), Effect.orElseSucceed(() => []));
    return new Set([...interfaces, ...resolved]);
  })
});
var UserId = Context.Reference("@t3tools/shared/HostProcess/UserId", {
  defaultValue: () => process.getuid?.()
});
var isWindows = Effect.map(Platform, (platform) => platform === "win32");

// ../../packages/shared/src/PtyAdapter.ts
import * as Context2 from "effect/Context";
import * as Schema3 from "effect/Schema";

class PtySpawnError extends Schema3.TaggedError()("PtySpawnError", {
  adapter: Schema3.String,
  shell: Schema3.optional(Schema3.String),
  attemptedShells: Schema3.optional(Schema3.Array(Schema3.String)),
  cause: Schema3.optional(Schema3.Defect())
}) {
  get message() {
    const shell = this.shell === undefined ? "" : ` '${this.shell}'`;
    const attemptedShells = this.attemptedShells === undefined || this.attemptedShells.length === 0 ? "" : ` Tried shells: ${this.attemptedShells.join(", ")}.`;
    return `Failed to spawn PTY process${shell} with ${this.adapter}.${attemptedShells}`;
  }
}
class PtyAdapter extends Context2.Service()("@t3tools/shared/PtyAdapter") {
}

// ../../packages/shared/src/shell.ts
import * as NodePath from "node:path";
import * as NodeChildProcess from "node:child_process";
import * as NodeFS from "node:fs";
import * as Cache from "effect/Cache";
import * as Clock from "effect/Clock";
import * as Duration from "effect/Duration";
import * as Effect2 from "effect/Effect";
import * as Exit from "effect/Exit";
import * as FileSystem from "effect/FileSystem";
import * as Option from "effect/Option";
import * as Path from "effect/Path";
import * as Context3 from "effect/Context";
var SHELL_ENV_NAME_PATTERN = /^[A-Z0-9_]+$/;
var WINDOWS_PATH_DELIMITER = ";";
var POSIX_PATH_DELIMITER = ":";
var WINDOWS_SHELL_CANDIDATES = ["pwsh.exe", "powershell.exe"];
var WINDOWS_SHELL_PROBE_TIMEOUT_MS = 5000;
var WINDOWS_SHELL_PROBE_DEADLINE = Duration.millis(WINDOWS_SHELL_PROBE_TIMEOUT_MS + 1000);
function canExecuteFile(filePath) {
  try {
    NodeFS.accessSync(filePath, NodeFS.constants.X_OK);
    return true;
  } catch {
    return false;
  }
}
var WINDOWS_SHELL_META_CHARS = /([()\][%!^"`<>&|;, *?])/g;
function escapeWindowsShellArg(arg) {
  let escaped = arg.replace(/(\\*)"/g, "$1$1\\\"");
  escaped = escaped.replace(/(\\*)$/, "$1$1");
  escaped = `"${escaped}"`;
  return escaped.replace(WINDOWS_SHELL_META_CHARS, "^$1");
}
async function resolveSpawnExecutableWithNode(command, platform, env) {
  const path = platform === "win32" ? NodePath.win32 : NodePath.posix;
  const windowsPathExtensions = platform === "win32" ? resolveWindowsPathExtensions(env) : [];
  const candidates = resolveCommandCandidates(command, platform, windowsPathExtensions, path.extname);
  const isExecutable = async (candidate) => {
    try {
      if (!(await NodeFS.promises.stat(candidate)).isFile())
        return false;
      if (platform === "win32") {
        return windowsPathExtensions.includes(path.extname(candidate).toUpperCase());
      }
      await NodeFS.promises.access(candidate, NodeFS.constants.X_OK);
      return true;
    } catch {
      return false;
    }
  };
  if (command.includes("/") || command.includes("\\")) {
    for (const candidate of candidates) {
      if (await isExecutable(candidate))
        return candidate;
    }
    return;
  }
  const pathValue = readEnvPath(env) ?? "";
  for (const pathEntry of pathValue.split(pathDelimiterForPlatform(platform))) {
    const emptyComponent = pathEntry === "" && pathValue !== "" && platform !== "win32";
    const normalizedPathEntry = emptyComponent ? "." : normalizePathEntry(pathEntry, platform);
    if (normalizedPathEntry.length === 0)
      continue;
    const names = platform === "win32" ? await listResolverPathDirectory(normalizedPathEntry, path.isAbsolute) : undefined;
    for (const candidate of candidates) {
      if (isAbsentFromListing(names, candidate))
        continue;
      const candidatePath = path.join(normalizedPathEntry, candidate);
      let probePath = candidatePath;
      if (emptyComponent) {
        try {
          probePath = path.resolve(candidatePath);
        } catch {
          continue;
        }
      }
      if (await isExecutable(probePath))
        return probePath;
    }
  }
  return;
}
var SpawnExecutableResolution = Context3.Reference("@t3tools/shared/shell/SpawnExecutableResolution", {
  defaultValue: () => resolveSpawnExecutableWithNode
});
function envCaptureStart(name) {
  return `__T3CODE_ENV_${name}_START__`;
}
function envCaptureEnd(name) {
  return `__T3CODE_ENV_${name}_END__`;
}
var DEBUG_TRAP_SHELLS = new Set(["bash", "zsh", "sh", "ksh", "ksh93"]);
var POSIX_CAPTURE_SYNTAX = { assignment: "__T3CODE_PRINTENV=$(", orElse: " || " };
var PRINTENV_CAPTURE_SYNTAX = new Map([...DEBUG_TRAP_SHELLS, "dash", "ash"].map((shell) => [shell, POSIX_CAPTURE_SYNTAX])).set("fish", { assignment: "set -l __T3CODE_PRINTENV (", orElse: "; or " });
function windowsEnvironmentValueCommand(name) {
  if (name === "PATH") {
    return "$value = (@(" + "[Environment]::GetEnvironmentVariable('PATH','Process')," + "[Environment]::GetEnvironmentVariable('PATH','Machine')," + "[Environment]::GetEnvironmentVariable('PATH','User')" + ") | Where-Object { $_ }) -join ';'";
  }
  return "$value = @(" + `[Environment]::GetEnvironmentVariable('${name}','Process'),` + `[Environment]::GetEnvironmentVariable('${name}','User'),` + `[Environment]::GetEnvironmentVariable('${name}','Machine')` + ") | Where-Object { $_ } | Select-Object -First 1";
}
function buildWindowsEnvironmentCaptureCommand(names) {
  return [
    "$ErrorActionPreference = 'Stop'",
    "try { [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false) } catch {}",
    ...names.flatMap((name) => {
      if (!SHELL_ENV_NAME_PATTERN.test(name)) {
        throw new Error(`Unsupported environment variable name: ${name}`);
      }
      return [
        `Write-Output '${envCaptureStart(name)}'`,
        windowsEnvironmentValueCommand(name),
        "if ($null -ne $value -and $value.Length -gt 0) { Write-Output $value }",
        `Write-Output '${envCaptureEnd(name)}'`
      ];
    })
  ].join("; ");
}
function extractEnvironmentValue(output, name) {
  const startMarker = envCaptureStart(name);
  const endMarker = envCaptureEnd(name);
  const startIndex = output.indexOf(startMarker);
  if (startIndex === -1)
    return;
  const valueStartIndex = startIndex + startMarker.length;
  const endIndex = output.indexOf(endMarker, valueStartIndex);
  if (endIndex === -1)
    return;
  const value = output.slice(valueStartIndex, endIndex).replace(/^\r?\n/, "").replace(/\r?\n$/, "");
  return value.length > 0 ? value : undefined;
}
var WindowsShellEnvironment = Context3.Reference("@t3tools/shared/shell/WindowsShellEnvironment", {
  defaultValue: () => readEnvironmentFromWindowsShell
});
var CommandAvailability = Context3.Reference("@t3tools/shared/shell/CommandAvailability", {
  defaultValue: () => isCommandAvailable
});
var execWindowsEnvironmentProbe = (file, args, options) => Effect2.callback((resume) => {
  let child;
  try {
    child = NodeChildProcess.execFile(file, args, { ...options, windowsHide: true }, (error, stdout) => {
      resume(Effect2.succeed(error ? Option.none() : Option.some(stdout)));
    });
  } catch {
    resume(Effect2.succeedNone);
    return;
  }
  return Effect2.sync(() => {
    child.kill();
    child.stdout?.destroy();
    child.stderr?.destroy();
    child.unref();
  });
});
var readEnvironmentFromWindowsShell = Effect2.fn("shell.readEnvironmentFromWindowsShell")(function* (names, options = {}, execFile2 = execWindowsEnvironmentProbe) {
  if (names.length === 0)
    return {};
  const command = buildWindowsEnvironmentCaptureCommand(names);
  const args = [
    "-NoLogo",
    ...options.loadProfile ? [] : ["-NoProfile"],
    "-NonInteractive",
    "-Command",
    command
  ];
  for (const shell of WINDOWS_SHELL_CANDIDATES) {
    const output = yield* execFile2(shell, args, {
      encoding: "utf8",
      timeout: WINDOWS_SHELL_PROBE_TIMEOUT_MS
    }).pipe(Effect2.timeoutOption(WINDOWS_SHELL_PROBE_DEADLINE), Effect2.map(Option.flatten));
    if (Option.isNone(output))
      continue;
    const environment = {};
    for (const name of names) {
      const value = extractEnvironmentValue(output.value, name);
      if (value !== undefined)
        environment[name] = value;
    }
    return environment;
  }
  return {};
});
function trimPathEntry(entry, platform) {
  return platform === "win32" ? entry.trim() : entry;
}
function normalizePathEntry(entry, platform) {
  return platform === "win32" ? entry.trim().replace(/^"+|"+$/g, "") : entry;
}
function pathDelimiterForPlatform(platform) {
  return platform === "win32" ? WINDOWS_PATH_DELIMITER : POSIX_PATH_DELIMITER;
}
function normalizePathEntryForComparison(entry, platform) {
  const normalized = normalizePathEntry(entry, platform);
  return platform === "win32" ? normalized.toLowerCase() : normalized;
}
function sanitizePathEntry(entry, platform) {
  return platform === "win32" ? entry.replaceAll('"', "") : entry;
}
function mergePathValues(preferredPath, inheritedPath, platform) {
  const delimiter = pathDelimiterForPlatform(platform);
  const merged = [];
  const seen = new Set;
  for (const rawValue of [preferredPath, inheritedPath]) {
    if (!rawValue)
      continue;
    for (const entry of rawValue.split(delimiter)) {
      const sanitized = sanitizePathEntry(trimPathEntry(entry, platform), platform);
      if (sanitized.length === 0)
        continue;
      const normalized = normalizePathEntryForComparison(sanitized, platform);
      if (normalized.length === 0 || seen.has(normalized))
        continue;
      seen.add(normalized);
      merged.push(sanitized);
    }
  }
  return merged.length > 0 ? merged.join(delimiter) : undefined;
}
function readEnvPath(env) {
  return env.PATH ?? env.Path ?? env.path;
}
function resolvePathEnvironmentVariable(env) {
  return readEnvPath(env) ?? "";
}
function resolveWindowsPathExtensions(env) {
  const rawValue = env.PATHEXT ?? Object.entries(env).find(([key, value]) => key.toUpperCase() === "PATHEXT" && value !== undefined)?.[1];
  const fallback = [".COM", ".EXE", ".BAT", ".CMD"];
  if (!rawValue)
    return fallback;
  const parsed = [];
  for (const entry of rawValue.split(";")) {
    const trimmed = entry.trim();
    if (trimmed.length === 0)
      continue;
    parsed.push(trimmed.startsWith(".") ? trimmed.toUpperCase() : `.${trimmed.toUpperCase()}`);
  }
  return parsed.length > 0 ? Array.from(new Set(parsed)) : fallback;
}
function resolveCommandCandidates(command, platform, windowsPathExtensions, extname) {
  if (platform !== "win32")
    return [command];
  const extension = extname(command);
  const normalizedExtension = extension.toUpperCase();
  if (extension.length > 0 && windowsPathExtensions.includes(normalizedExtension)) {
    const commandWithoutExtension = command.slice(0, -extension.length);
    return Array.from(new Set([
      command,
      `${commandWithoutExtension}${normalizedExtension}`,
      `${commandWithoutExtension}${normalizedExtension.toLowerCase()}`
    ]));
  }
  const candidates = [];
  for (const candidateExtension of windowsPathExtensions) {
    candidates.push(`${command}${candidateExtension}`);
    candidates.push(`${command}${candidateExtension.toLowerCase()}`);
  }
  return Array.from(new Set(candidates));
}
var COMMAND_RESOLUTION_CACHE_TTL_NANOS = 30000000000n;
var COMMAND_RESOLUTION_CACHE_MAX_ENTRIES = 512;
var COMMAND_RESOLUTION_CACHE_KEY_SEPARATOR = String.fromCharCode(0);
var CommandResolutionCache = Context3.Reference("@t3tools/shared/shell/CommandResolutionCache", {
  defaultValue: () => new Map
});
var PATH_DIRECTORY_LISTINGS_MAX_ENTRIES = 1024;
var PATH_DIRECTORY_SETTLE_MS = 2000;
var NO_DIRECTORY_NAMES = new Set;
var LISTED_NAME_PATTERN = /^[\w.+-]*[\w+-]$/;
function isAbsentFromListing(names, candidate) {
  return names !== undefined && LISTED_NAME_PATTERN.test(candidate) && !names.has(candidate.toLowerCase());
}
function isReusableListing(directory, modified, listedAtMs, isAbsolute2) {
  return isAbsolute2(directory) && listedAtMs - modified >= PATH_DIRECTORY_SETTLE_MS;
}
var directoryMtime = (directory) => FileSystem.FileSystem.use((fileSystem) => fileSystem.stat(directory)).pipe(Effect2.map((info) => info.type === "Directory" ? Option.getOrUndefined(info.mtime)?.getTime() : undefined), Effect2.catch((error) => Effect2.succeed(error.reason._tag === "NotFound" ? null : undefined)));
var listPathDirectory = Effect2.fnUntraced(function* (directory) {
  const path = yield* Path.Path;
  const modified = yield* directoryMtime(directory);
  if (modified === null) {
    return { modified, names: NO_DIRECTORY_NAMES, reusable: path.isAbsolute(directory) };
  }
  if (modified === undefined)
    return { modified, names: undefined, reusable: false };
  const listedAtMs = yield* Clock.currentTimeMillis;
  const entries = yield* FileSystem.FileSystem.use((fileSystem) => fileSystem.readDirectory(directory)).pipe(Effect2.orElseSucceed(() => {
    return;
  }));
  return {
    modified,
    names: entries && new Set(entries.map((entry) => entry.toLowerCase())),
    reusable: entries !== undefined && isReusableListing(directory, modified, listedAtMs, path.isAbsolute)
  };
});
var makePathDirectoryListings = Cache.makeWith(listPathDirectory, {
  capacity: PATH_DIRECTORY_LISTINGS_MAX_ENTRIES,
  timeToLive: (exit) => Exit.isSuccess(exit) && exit.value.reusable ? Duration.infinity : Duration.zero,
  requireServicesAt: "lookup"
});
var PathDirectoryListings = Context3.Reference("@t3tools/shared/shell/PathDirectoryListings", { defaultValue: () => Effect2.runSync(makePathDirectoryListings) });
var resolverPathDirectoryListings = new Map;
async function listResolverPathDirectory(directory, isAbsolute2) {
  let modified;
  try {
    const stats = await NodeFS.promises.stat(directory);
    if (!stats.isDirectory())
      return;
    modified = stats.mtimeMs;
  } catch (error) {
    return error.code === "ENOENT" ? NO_DIRECTORY_NAMES : undefined;
  }
  const cached = resolverPathDirectoryListings.get(directory);
  if (cached?.modified === modified)
    return cached.names;
  resolverPathDirectoryListings.delete(directory);
  const listedAtMs = Date.now();
  let names;
  try {
    names = new Set((await NodeFS.promises.readdir(directory)).map((entry) => entry.toLowerCase()));
  } catch {
    return;
  }
  if (isReusableListing(directory, modified, listedAtMs, isAbsolute2)) {
    if (resolverPathDirectoryListings.size >= PATH_DIRECTORY_LISTINGS_MAX_ENTRIES) {
      const oldest = resolverPathDirectoryListings.keys().next().value;
      if (oldest !== undefined)
        resolverPathDirectoryListings.delete(oldest);
    }
    resolverPathDirectoryListings.set(directory, { modified, names });
  }
  return names;
}
var spawnResolverCacheIdCount = 0;
var spawnResolverCacheIds = new WeakMap;
function spawnResolverCacheId(resolver) {
  const known = spawnResolverCacheIds.get(resolver);
  if (known !== undefined)
    return known;
  const id = spawnResolverCacheIdCount++;
  spawnResolverCacheIds.set(resolver, id);
  return id;
}
function cacheCommandResolution(cache, cacheKey, resolvedPath, nowNanos) {
  if (cache.size >= COMMAND_RESOLUTION_CACHE_MAX_ENTRIES) {
    const oldestKey = cache.keys().next().value;
    if (oldestKey !== undefined) {
      cache.delete(oldestKey);
    }
  }
  cache.set(cacheKey, {
    resolvedPath,
    expiresAtNanos: nowNanos + COMMAND_RESOLUTION_CACHE_TTL_NANOS
  });
}
var isExecutableFile = Effect2.fnUntraced(function* (filePath, platform, windowsPathExtensions) {
  const fileSystem = yield* FileSystem.FileSystem;
  const path = yield* Path.Path;
  const stat = yield* fileSystem.stat(filePath).pipe(Effect2.orElseSucceed(() => null));
  if (stat === null || stat.type !== "File")
    return false;
  if (platform === "win32") {
    const extension = path.extname(filePath);
    if (extension.length === 0)
      return false;
    return windowsPathExtensions.includes(extension.toUpperCase());
  }
  return canExecuteFile(filePath);
});
function pathEntriesForPlatform(pathValue, platform) {
  const pathEntries = [];
  const seenPathEntries = new Set;
  for (const entry of pathValue.split(pathDelimiterForPlatform(platform))) {
    const pathEntry = entry === "" && pathValue !== "" && platform !== "win32" ? "." : normalizePathEntry(entry, platform);
    if (pathEntry.length === 0 || seenPathEntries.has(pathEntry))
      continue;
    seenPathEntries.add(pathEntry);
    pathEntries.push(pathEntry);
  }
  return pathEntries;
}
function pathSearchCwd(pathValue, platform) {
  if (platform === "win32")
    return;
  if (pathEntriesForPlatform(pathValue, platform).every((entry) => NodePath.posix.isAbsolute(entry))) {
    return;
  }
  try {
    return process.cwd();
  } catch {
    return null;
  }
}
var findOnPath = Effect2.fnUntraced(function* (pathValue, commandCandidates, platform, windowsPathExtensions, isLast, cwd) {
  const path = yield* Path.Path;
  const pathEntries = pathEntriesForPlatform(pathValue, platform);
  const anchorsCwd = typeof cwd === "string" && pathValue.split(pathDelimiterForPlatform(platform)).find((entry) => entry === "" || entry === ".") === "";
  const listings = platform === "win32" ? yield* PathDirectoryListings : undefined;
  const matches = [];
  for (const pathEntry of pathEntries) {
    let listing = listings && (yield* Cache.get(listings, pathEntry));
    if (listings && listing?.names && listing.modified !== (yield* directoryMtime(pathEntry))) {
      yield* Cache.invalidate(listings, pathEntry);
      listing = yield* Cache.get(listings, pathEntry);
    }
    for (const candidate of commandCandidates) {
      if (isAbsentFromListing(listing?.names, candidate))
        continue;
      const match = anchorsCwd && pathEntry === "." ? path.join(cwd, candidate) : path.join(pathEntry, candidate);
      if (yield* isExecutableFile(match, platform, windowsPathExtensions)) {
        matches.push(match);
        if (isLast(match))
          return matches;
        break;
      }
    }
  }
  return matches;
});
var resolveCommandPathForPlatform = Effect2.fn("shell.resolveCommandPathForPlatform")(function* (command, options) {
  const path = yield* Path.Path;
  const platform = options.platform;
  const env = options.env ?? process.env;
  const windowsPathExtensions = platform === "win32" ? resolveWindowsPathExtensions(env) : [];
  const commandCandidates = resolveCommandCandidates(command, platform, windowsPathExtensions, path.extname);
  if (command.includes("/") || command.includes("\\")) {
    for (const candidate of commandCandidates) {
      if (yield* isExecutableFile(candidate, platform, windowsPathExtensions)) {
        return candidate;
      }
    }
    return null;
  }
  const pathValue = resolvePathEnvironmentVariable(env);
  if (pathValue.length === 0) {
    return null;
  }
  const cwd = pathSearchCwd(pathValue, platform);
  const cacheKey = [
    platform,
    pathValue,
    windowsPathExtensions.join(";"),
    command,
    ...cwd === undefined ? [] : [cwd]
  ].join(COMMAND_RESOLUTION_CACHE_KEY_SEPARATOR);
  const cache = yield* CommandResolutionCache;
  const nowNanos = yield* Clock.monotonicTimeNanos;
  const cached = cwd === null ? undefined : cache.get(cacheKey);
  if (cached !== undefined && cached.expiresAtNanos > nowNanos) {
    return cached.resolvedPath;
  }
  const [resolvedPath = null] = yield* findOnPath(pathValue, commandCandidates, platform, windowsPathExtensions, () => true, cwd);
  if (cwd !== null)
    cacheCommandResolution(cache, cacheKey, resolvedPath, nowNanos);
  return resolvedPath;
});
var resolveCommandPath = Effect2.fn("shell.resolveCommandPath")(function* (command, options = {}) {
  return yield* resolveCommandPathForPlatform(command, {
    env: options.env ?? (yield* Environment),
    platform: yield* Platform
  });
});
var resolveCommandPaths = Effect2.fn("shell.resolveCommandPaths")(function* (command, options) {
  const path = yield* Path.Path;
  const platform = yield* Platform;
  const env = options.env ?? (yield* Environment);
  const windowsPathExtensions = platform === "win32" ? resolveWindowsPathExtensions(env) : [];
  const pathValue = resolvePathEnvironmentVariable(env);
  return yield* findOnPath(pathValue, resolveCommandCandidates(command, platform, windowsPathExtensions, path.extname), platform, windowsPathExtensions, options.until, pathSearchCwd(pathValue, platform));
});
var GIT_FOR_WINDOWS_BUILDS = ["ucrt64", "clangarm64", "mingw64", "mingw32"];
function isFileSync(filePath) {
  try {
    return NodeFS.statSync(filePath).isFile();
  } catch {
    return false;
  }
}
function preferGitForWindowsBinary(executable, env, isFile = isFileSync) {
  if (env.MSYSTEM)
    return executable;
  const path = NodePath.win32;
  if (path.basename(executable).toLowerCase() !== "git.exe")
    return executable;
  const launcherDirectory = path.dirname(executable);
  const launcherFolder = path.basename(launcherDirectory).toLowerCase();
  if (launcherFolder !== "cmd" && launcherFolder !== "bin")
    return executable;
  const installRoot = path.dirname(launcherDirectory);
  for (const build of GIT_FOR_WINDOWS_BUILDS) {
    const candidate = path.join(installRoot, build, "bin", "git.exe");
    if (isFile(candidate))
      return candidate;
  }
  return executable;
}
var NPM_EXECUTABLE_SHIM_PREFIX = [
  "@ECHO off",
  "GOTO start",
  ":find_dp0",
  "SET dp0=%~dp0",
  "EXIT /b",
  ":start",
  "SETLOCAL",
  "CALL :find_dp0"
];
var NPM_EXECUTABLE_SHIM_RUN = /^"%dp0%\\([^"%]+\.exe)" +%\*$/;
function readFileSyncOrUndefined(filePath) {
  try {
    return NodeFS.readFileSync(filePath, "utf8");
  } catch {
    return;
  }
}
function npmShimExecutable(shimPath, readFile = readFileSyncOrUndefined, isFile = isFileSync) {
  const path = NodePath.win32;
  if (path.extname(shimPath).toLowerCase() !== ".cmd")
    return;
  const lines = readFile(shimPath)?.split(/\r?\n/).filter((line) => line.length > 0);
  if (lines?.length !== NPM_EXECUTABLE_SHIM_PREFIX.length + 1)
    return;
  if (NPM_EXECUTABLE_SHIM_PREFIX.some((expected, index) => lines[index] !== expected)) {
    return;
  }
  const target = NPM_EXECUTABLE_SHIM_RUN.exec(lines.at(-1))?.[1];
  if (target === undefined)
    return;
  const executable = path.join(path.dirname(shimPath), target);
  return isFile(executable) ? executable : undefined;
}
function locateXcodeGitWithXcrun(env) {
  try {
    const located = NodeChildProcess.execFileSync("/usr/bin/xcrun", ["--find", "git"], {
      encoding: "utf8",
      env,
      timeout: 5000,
      stdio: ["ignore", "pipe", "ignore"]
    }).trim();
    return NodePath.isAbsolute(located) ? located : undefined;
  } catch {
    return;
  }
}
var XcodeGitLocation = Context3.Reference("@t3tools/shared/shell/XcodeGitLocation", { defaultValue: () => locateXcodeGitWithXcrun });
var MACOS_GIT_SHIM = "/usr/bin/git";
var resolveMacosGit = Effect2.fnUntraced(function* (env, resolveExecutable) {
  const locateXcodeGit = yield* XcodeGitLocation;
  const cache = yield* CommandResolutionCache;
  const pathValue = resolvePathEnvironmentVariable(env);
  const nowNanos = yield* Clock.currentTimeNanos;
  const cwd = pathSearchCwd(pathValue, "darwin");
  const cacheKey = [
    "xcode-git",
    String(spawnResolverCacheId(resolveExecutable)),
    String(spawnResolverCacheId(locateXcodeGit)),
    pathValue,
    env.DEVELOPER_DIR ?? "",
    ...cwd === undefined ? [] : [cwd]
  ].join(COMMAND_RESOLUTION_CACHE_KEY_SEPARATOR);
  const cached = cwd === null ? undefined : cache.get(cacheKey);
  if (cached !== undefined && cached.expiresAtNanos > nowNanos) {
    const cachedPath = cached.resolvedPath;
    if (cachedPath === null || (yield* Effect2.promise(async () => resolveExecutable(cachedPath, "darwin", env))) !== undefined) {
      return cachedPath ?? "git";
    }
  }
  const pathGit = yield* Effect2.promise(async () => resolveExecutable("git", "darwin", env));
  const located = pathGit === MACOS_GIT_SHIM ? locateXcodeGit(env) : undefined;
  const realGit = located !== undefined && (yield* Effect2.promise(async () => resolveExecutable(located, "darwin", env))) !== undefined ? located : typeof cwd === "string" && pathGit === NodePath.posix.join(cwd, "git") ? pathGit : null;
  if (cwd !== null && pathSearchCwd(pathValue, "darwin") === cwd) {
    cacheCommandResolution(cache, cacheKey, realGit, nowNanos);
  }
  return realGit ?? "git";
});
var CONSOLE_FREE_GIT_READS = [
  "rev-parse --git-path index",
  "rev-parse --git-common-dir",
  "rev-parse --show-toplevel",
  "rev-parse --git-common-dir --show-toplevel",
  "rev-parse --path-format=absolute --git-path index --git-common-dir --show-toplevel",
  "rev-parse --symbolic-full-name HEAD",
  "rev-parse --abbrev-ref --symbolic-full-name @{upstream}",
  "symbolic-ref --quiet HEAD",
  "symbolic-ref *",
  "remote",
  "remote get-url *",
  "remote get-url -- *",
  "config --get *"
].map((form) => form.split(" "));
var resolveSpawnCommand = Effect2.fnUntraced(function* (command, args, options = {}) {
  const platform = yield* Platform;
  const isMacosGit = platform === "darwin" && command === "git";
  if (platform !== "win32" && !isMacosGit) {
    return { command, args: [...args], shell: false };
  }
  const hostEnvironment = yield* Environment;
  const env = options.env === undefined ? hostEnvironment : options.extendEnv ? { ...hostEnvironment, ...options.env } : options.env;
  const resolveExecutable = yield* SpawnExecutableResolution;
  if (isMacosGit) {
    return {
      command: yield* resolveMacosGit(env, resolveExecutable),
      args: [...args],
      shell: false
    };
  }
  const explicitPath = command.includes("/") || command.includes("\\");
  const cache = yield* CommandResolutionCache;
  const cacheKey = [
    "spawn",
    String(spawnResolverCacheId(resolveExecutable)),
    platform,
    resolvePathEnvironmentVariable(env),
    resolveWindowsPathExtensions(env).join(";"),
    env.MSYSTEM ? "msystem" : "",
    command
  ].join(COMMAND_RESOLUTION_CACHE_KEY_SEPARATOR);
  const nowNanos = yield* Clock.currentTimeNanos;
  const cached = explicitPath ? undefined : cache.get(cacheKey);
  let resolvedExecutable;
  if (cached !== undefined && cached.expiresAtNanos > nowNanos) {
    resolvedExecutable = cached.resolvedPath;
  } else {
    const found = yield* Effect2.promise(async () => resolveExecutable(command, platform, env));
    resolvedExecutable = found === undefined ? null : preferGitForWindowsBinary(found, env);
    if (!explicitPath && resolvedExecutable !== null) {
      cacheCommandResolution(cache, cacheKey, resolvedExecutable, nowNanos);
    }
  }
  const resolvedCommand = resolvedExecutable ?? command;
  const extension = NodePath.win32.extname(resolvedCommand).toLowerCase();
  if (extension !== ".cmd" && extension !== ".bat") {
    return { command: resolvedCommand, args: [...args], shell: false };
  }
  const shimExecutable = options.bypassNpmShim ? npmShimExecutable(resolvedCommand) : undefined;
  if (shimExecutable !== undefined) {
    return { command: shimExecutable, args: [...args], shell: false };
  }
  return {
    command: [resolvedCommand, ...args].map(escapeWindowsShellArg).join(" "),
    args: [],
    shell: true
  };
});
var isCommandAvailable = Effect2.fn("shell.isCommandAvailable")(function* (command, options = {}) {
  return (yield* resolveCommandPath(command, options)) !== null;
});
function resolveKnownWindowsCliDirs(env) {
  const appData = env.APPDATA?.trim();
  const localAppData = env.LOCALAPPDATA?.trim();
  const userProfile = env.USERPROFILE?.trim();
  return [
    ...appData ? [`${appData}\\npm`] : [],
    ...localAppData ? [`${localAppData}\\Programs\\nodejs`, `${localAppData}\\Volta\\bin`] : [],
    ...localAppData ? [`${localAppData}\\pnpm`] : [],
    ...userProfile ? [`${userProfile}\\.local\\bin`, `${userProfile}\\.bun\\bin`, `${userProfile}\\scoop\\shims`] : []
  ];
}
function setWindowsPath(env, value) {
  for (const key of Object.keys(env)) {
    if (key.toUpperCase() === "PATH") {
      delete env[key];
    }
  }
  if (value !== null)
    env.PATH = value;
}
function mergeWindowsEnv(currentEnv, patch) {
  const nextEnv = { ...currentEnv };
  for (const [key, value] of Object.entries(patch)) {
    if (value === undefined)
      continue;
    if (key === "PATH") {
      setWindowsPath(nextEnv, value);
    } else {
      nextEnv[key] = value;
    }
  }
  return nextEnv;
}
var resolveWindowsEnvironment = Effect2.fn("shell.resolveWindowsEnvironment")(function* (env) {
  const readEnvironment = yield* WindowsShellEnvironment;
  const commandAvailable = yield* CommandAvailability;
  const inheritedPath = readEnvPath(env);
  const shellPath = (yield* readEnvironment(["PATH"], { loadProfile: false })).PATH;
  const mergedPath = mergePathValues(shellPath, inheritedPath, "win32");
  const knownCliPath = resolveKnownWindowsCliDirs(env).join(WINDOWS_PATH_DELIMITER);
  const baselinePath = mergePathValues(mergedPath, knownCliPath, "win32");
  const baselinePatch = baselinePath ? { PATH: baselinePath } : {};
  const baselineEnv = mergeWindowsEnv(env, baselinePatch);
  if (yield* commandAvailable("node", { env: baselineEnv })) {
    return baselinePatch;
  }
  const profiledEnvironment = yield* readEnvironment(["PATH", "FNM_DIR", "FNM_MULTISHELL_PATH"], {
    loadProfile: true
  });
  const profiledPath = mergePathValues(profiledEnvironment.PATH, baselinePath, "win32");
  const profiledPatch = {
    ...profiledPath ? { PATH: profiledPath } : {},
    ...profiledEnvironment.FNM_DIR ? { FNM_DIR: profiledEnvironment.FNM_DIR } : {},
    ...profiledEnvironment.FNM_MULTISHELL_PATH ? { FNM_MULTISHELL_PATH: profiledEnvironment.FNM_MULTISHELL_PATH } : {}
  };
  return Object.keys(profiledPatch).length > 0 ? { ...baselinePatch, ...profiledPatch } : baselinePatch;
});

// src/sync.ts
import * as Context4 from "effect/Context";
import * as SecureRandom from "effect/crypto/SecureRandom";
import * as DateTime from "effect/DateTime";
import * as Effect3 from "effect/Effect";
import * as Fiber from "effect/Fiber";
import * as FileSystem3 from "effect/FileSystem";
import * as Option2 from "effect/Option";
import * as Path3 from "effect/Path";
import { ChildProcess, ChildProcessSpawner } from "effect/process";
import * as Schema4 from "effect/Schema";
import * as Semaphore from "effect/Semaphore";
import * as Stream from "effect/Stream";

// src/instructions.ts
var LINE_BREAKING = /[\p{Cc}\p{Zl}\p{Zp}]/gu;
var folderPath = (value) => value.replaceAll(LINE_BREAKING, "?").replaceAll("<", "‹").replaceAll(">", "›");
function buildSharedMemoryInstructions(memory) {
  return `<shared_memory>Shared agent identity: ${folderPath(memory.agentId)}. Shared memory folder: ${folderPath(memory.folder)}. Read MEMORY.md before starting. Save durable learnings as one-fact Markdown notes in notes/ linked from MEMORY.md. After fixing a notable issue, write issues/YYYY-MM-DD-<slug>.md with problem, root cause, fix, repo, and machine. Preserve other agents' notes; never store secrets.</shared_memory>`;
}

// src/sync.ts
var Preferences = Schema4.Struct({
  vault: Schema4.String,
  folder: Schema4.String,
  enabled: Schema4.Boolean,
  paused: Schema4.Boolean,
  agentId: Schema4.String
});
var Identity = Schema4.Struct({ agentId: Schema4.String, createdAt: Schema4.String });
var decodePreferences = Schema4.decodeEffect(Schema4.fromJsonString(Preferences));
var encodePreferences = Schema4.encodeEffect(Schema4.fromJsonString(Preferences));
var decodeIdentity = Schema4.decodeEffect(Schema4.fromJsonString(Identity));
var encodeIdentity = Schema4.encodeEffect(Schema4.fromJsonString(Identity));
var decodeVaults = Schema4.decodeEffect(Schema4.fromJsonString(SharedMemoryVaults));
var TOKEN_KEY = "token";
var Binary = Context4.Reference("p0code/obsidian-shared-memory/Binary", {
  defaultValue: () => "ob"
});
var failure = (stage) => new PluginError({
  message: `Shared memory ${stage} failed. Check Obsidian Headless (ob) is installed with Node 22+, your credentials, and vault access.`
});
var makeSharedMemorySync = Effect3.gen(function* () {
  const context = yield* PluginContext;
  const platform = yield* Platform;
  const fs = yield* FileSystem3.FileSystem;
  const path = yield* Path3.Path;
  const crypto = yield* SecureRandom.SecureRandom;
  const spawner = yield* ChildProcessSpawner.ChildProcessSpawner;
  const pty = yield* PtyAdapter;
  const binary = yield* Binary;
  const scope2 = yield* Effect3.scope;
  const lock = yield* Semaphore.make(1);
  const home = path.join(context.dataDir, "obsidian-headless-home");
  const prefsPath = path.join(context.dataDir, "shared-memory.json");
  const authPath = platform === "linux" ? path.join(home, ".config/obsidian-headless/auth_token") : path.join(home, ".obsidian-headless/auth_token");
  let preferences = {
    vault: "",
    folder: "",
    enabled: false,
    paused: true,
    agentId: ""
  };
  let identity = "";
  let phase = "idle";
  let lastSyncedAt = null;
  let lastError = null;
  let worker;
  const stored = yield* fs.readFileString(prefsPath).pipe(Effect3.result);
  if (stored._tag === "Success") {
    const decoded = yield* decodePreferences(stored.success).pipe(Effect3.result);
    if (decoded._tag === "Success")
      preferences = decoded.success;
    else
      lastError = "Saved shared memory configuration could not be read.";
  }
  yield* fs.makeDirectory(home, { recursive: true, mode: 448 }).pipe(Effect3.ignore);
  const token = context.storage.get(TOKEN_KEY);
  const environment = Effect3.fn("SharedMemorySync.environment")(function* () {
    const saved = yield* token;
    return {
      ...process.env,
      HOME: home,
      USERPROFILE: home,
      XDG_CONFIG_HOME: path.join(home, ".config"),
      OBSIDIAN_AUTH_TOKEN: Option2.getOrElse(saved, () => "")
    };
  });
  const nodeSupported = Number(process.versions.node.split(".")[0]) >= 22;
  const run = Effect3.fn("SharedMemorySync.run")(function* (args, stdin = "", onLine) {
    if (!nodeSupported)
      return yield* failure("Node 22 requirement");
    const env = yield* environment();
    return yield* Effect3.scoped(Effect3.gen(function* () {
      const resolved = yield* resolveSpawnCommand(binary, args, { env, extendEnv: false });
      const child = yield* spawner.spawn(ChildProcess.make(resolved.command, resolved.args, {
        shell: resolved.shell,
        env,
        extendEnv: false,
        stdin: Stream.make(Buffer.from(stdin))
      }));
      const [output, , code] = yield* Effect3.all([
        child.stdout.pipe(Stream.decodeText(), Stream.splitLines, Stream.tap((line) => onLine?.(line) ?? Effect3.void), Stream.runFold(() => "", (text, chunk) => (text + chunk + `
`).slice(-1e6))),
        child.stderr.pipe(Stream.runDrain),
        child.exitCode
      ], { concurrency: "unbounded" });
      if (code !== 0)
        return yield* failure(args[0] ?? "command");
      return output;
    })).pipe((effect) => args.includes("--continuous") ? effect : effect.pipe(Effect3.timeout("90 seconds")), Effect3.mapError(() => failure(args[0] ?? "command")));
  });
  const save = Effect3.fn("SharedMemorySync.save")(function* () {
    yield* fs.writeFileString(`${prefsPath}.tmp`, yield* encodePreferences(preferences), {
      mode: 384
    });
    yield* fs.rename(`${prefsPath}.tmp`, prefsPath);
  }, Effect3.mapError(() => failure("save preferences")));
  const readIdentity = Effect3.fn("SharedMemorySync.readIdentity")(function* () {
    const text = yield* fs.readFileString(path.join(preferences.folder, "agent.json"));
    const value = yield* decodeIdentity(text);
    identity = value.agentId;
    return identity;
  }, Effect3.mapError(() => failure("read shared identity")));
  const skeleton = Effect3.fn("SharedMemorySync.skeleton")(function* () {
    for (const dir of ["notes", "issues"])
      yield* fs.makeDirectory(path.join(preferences.folder, dir), { recursive: true });
    const files = {
      "agent.json": yield* encodeIdentity({
        agentId: yield* crypto.uuidV4(),
        createdAt: DateTime.formatIso(yield* DateTime.now)
      }),
      "MEMORY.md": `# Shared memory

Link durable one-fact notes here.

## Notes

## Issues
`,
      "README.md": `# Shared agent memory

Read MEMORY.md before work. Store one durable fact per Markdown note in notes/ and link it from MEMORY.md. After a notable fix, add issues/YYYY-MM-DD-<slug>.md with problem, root cause, fix, repo, and machine. Preserve concurrent agents' notes and never store credentials. agent.json holds the shared identity; keep it synced.

For Claude Code, Codex CLI, and other harnesses outside p0code, copy the instruction snippet from the Obsidian shared memory plugin's settings into the harness instructions, using that machine's absolute vault path.

Do not enable Obsidian desktop Sync for a vault managed by Headless Sync on the same machine.
`
    };
    for (const [name, content] of Object.entries(files)) {
      yield* fs.writeFileString(path.join(preferences.folder, name), content, { flag: "wx" }).pipe(Effect3.catchTags({
        PlatformError: (error) => error.reason._tag === "AlreadyExists" ? Effect3.void : Effect3.fail(error)
      }));
    }
    yield* readIdentity();
  }, Effect3.mapError(() => failure("initialize vault")));
  const stop = Effect3.fn("SharedMemorySync.stop")(function* () {
    if (worker) {
      yield* Fiber.interrupt(worker);
      worker = undefined;
    }
    phase = "idle";
  });
  const reportStatus = Effect3.suspend(() => context.reportStatus(!preferences.folder ? null : preferences.paused ? `Paused · ${preferences.vault}` : phase === "error" ? lastError ?? "Sync error" : `Syncing ${preferences.vault}`));
  const start = Effect3.fn("SharedMemorySync.start")(function* () {
    yield* stop();
    yield* reportStatus;
    if (!preferences.folder || preferences.paused || Option2.isNone(yield* token))
      return;
    const sync3 = Effect3.gen(function* () {
      let failures = 0;
      while (true) {
        phase = "syncing";
        yield* run(["sync", "--path", preferences.folder, "--continuous"], "", (line) => line.includes("Fully synced") ? Effect3.gen(function* () {
          lastSyncedAt = DateTime.formatIso(yield* DateTime.now);
          lastError = null;
          failures = 0;
          phase = "idle";
          yield* readIdentity().pipe(Effect3.ignore);
          yield* reportStatus;
        }) : Effect3.void).pipe(Effect3.ignore);
        phase = "error";
        lastError = "Obsidian sync stopped unexpectedly; reconnecting.";
        yield* reportStatus;
        failures++;
        yield* Effect3.sleep(Math.min(60, failures ? 2 ** Math.min(failures, 6) : 10) * 1000);
      }
    });
    worker = yield* sync3.pipe(Effect3.forkIn(scope2));
  });
  const agentInstructions = Effect3.gen(function* () {
    if (!preferences.enabled || !preferences.folder || Option2.isNone(yield* token))
      return null;
    const result2 = yield* readIdentity().pipe(Effect3.result);
    if (result2._tag === "Failure")
      return null;
    return buildSharedMemoryInstructions({
      folder: preferences.folder,
      agentId: preferences.agentId || result2.success
    });
  }).pipe(Effect3.orElseSucceed(() => null));
  const status = Effect3.fn("SharedMemorySync.status")(function* () {
    const memory = preferences.folder ? { folder: preferences.folder, agentId: preferences.agentId || identity } : undefined;
    return {
      connected: Option2.isSome(yield* token),
      phase,
      ...preferences,
      agentId: memory?.agentId ?? "",
      lastSyncedAt,
      lastError,
      snippet: memory ? buildSharedMemoryInstructions(memory) : ""
    };
  });
  const login = Effect3.fn("SharedMemorySync.login")(function* (input) {
    yield* stop();
    const env = yield* environment();
    env.OBSIDIAN_AUTH_TOKEN = "";
    yield* fs.remove(authPath, { force: true }).pipe(Effect3.mapError(() => failure("clear credential")));
    yield* Effect3.scoped(Effect3.gen(function* () {
      const child = yield* pty.spawn({ shell: binary, args: ["login"], cwd: home, cols: 80, rows: 24, env }).pipe(Effect3.mapError(() => failure("login")));
      yield* Effect3.addFinalizer(() => Effect3.sync(() => {
        try {
          child.kill();
        } catch {}
      }));
      yield* Effect3.callback((resume) => {
        let pending = "";
        const sent = new Set;
        const offData = child.onData((data) => {
          pending = (pending + data).slice(-4096);
          for (const [prompt, value] of [
            ["Email: ", input.email],
            ["Password: ", input.password],
            ["2FA code: ", input.mfa ?? ""]
          ]) {
            if (!sent.has(prompt) && pending.includes(prompt)) {
              sent.add(prompt);
              pending = "";
              if (!value || /[\r\n\x03]/.test(value)) {
                resume(Effect3.fail(failure("login (MFA may be required)")));
                return;
              }
              child.write(value);
              child.write("\r");
            }
          }
        });
        const offExit = child.onExit(({ exitCode }) => resume(exitCode === 0 ? Effect3.void : Effect3.fail(failure("login"))));
        return Effect3.sync(() => {
          offData();
          offExit();
        });
      }).pipe(Effect3.timeout("90 seconds"), Effect3.mapError(() => failure("login")));
      const saved = yield* fs.readFileString(authPath).pipe(Effect3.mapError(() => failure("read login token")));
      yield* context.storage.set(TOKEN_KEY, saved).pipe(Effect3.mapError(() => failure("save credential")));
    })).pipe(Effect3.ensuring(fs.remove(authPath, { force: true }).pipe(Effect3.ignore)));
  });
  const command = Effect3.fn("SharedMemorySync.command")(function* (input) {
    switch (input.action) {
      case "login":
        yield* login(input);
        break;
      case "configure": {
        yield* stop();
        const folder = input.folder.trim() || path.join(context.dataDir, "shared-memory", Buffer.from(input.vault).toString("base64url"));
        if (!path.isAbsolute(folder) || !input.vault.trim())
          return yield* failure("validate vault path");
        yield* run(["sync-setup", "--vault", input.vault, "--path", folder], input.password ?? "");
        yield* run([
          "sync-config",
          "--path",
          folder,
          "--file-types",
          "image,audio,video,pdf,unsupported"
        ]);
        yield* run(["sync", "--path", folder]);
        lastSyncedAt = DateTime.formatIso(yield* DateTime.now);
        preferences = { ...preferences, vault: input.vault, folder, paused: false };
        yield* skeleton();
        yield* save();
        yield* start();
        break;
      }
      case "preferences":
        preferences = { ...preferences, enabled: input.enabled, agentId: input.agentId.trim() };
        yield* save();
        break;
      case "pause":
        preferences = { ...preferences, paused: true };
        yield* stop();
        yield* save();
        yield* reportStatus;
        break;
      case "resume":
        preferences = { ...preferences, paused: false };
        yield* save();
        yield* start();
        break;
      case "logout":
        yield* stop();
        yield* run(["logout"]);
        yield* context.storage.remove(TOKEN_KEY).pipe(Effect3.mapError(() => failure("remove credential")));
        preferences = { ...preferences, enabled: false, paused: true };
        yield* save();
        yield* reportStatus;
        break;
    }
    lastError = null;
    return yield* status();
  }, Effect3.tapError((error) => Effect3.sync(() => {
    lastError = error.message;
    phase = "error";
  })), lock.withPermits(1));
  if (preferences.folder)
    yield* readIdentity().pipe(Effect3.ignore);
  yield* start().pipe(Effect3.ignore);
  return {
    status: status(),
    command,
    agentInstructions,
    vaults: run(["sync-list-remote", "--json"]).pipe(Effect3.flatMap((output) => decodeVaults(output)), Effect3.mapError(() => failure("list vaults")))
  };
});

// src/index.ts
var obsidianSharedMemory = definePlugin({
  manifest: {
    id: OBSIDIAN_SHARED_MEMORY_ID,
    name: "Obsidian shared memory",
    description: "Syncs a shared agent memory folder through Obsidian Sync (Obsidian Headless) and tells every agent turn where it is, so agents on all your machines read and add to the same notes.",
    version: "0.1.0",
    unofficial: true,
    externalServices: ["Obsidian Sync"],
    capabilities: ["network:outbound", "process:spawn", "agent:instructions"],
    httpRoutes: []
  },
  actions: sharedMemoryActions,
  start: Effect4.gen(function* () {
    const sync3 = yield* makeSharedMemorySync;
    return {
      actions: {
        status: () => sync3.status,
        vaults: () => sync3.vaults,
        command: sync3.command
      },
      agentInstructions: sync3.agentInstructions
    };
  })
});
export {
  obsidianSharedMemory
};
