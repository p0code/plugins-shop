// src/index.ts
import { definePlugin } from "@t3tools/plugin-api";
import * as Effect10 from "effect/Effect";
import * as Queue2 from "effect/Queue";

// src/actions.ts
import * as Effect from "effect/Effect";
import * as Schema from "effect/Schema";
var T3_CONNECT_BRIDGE_ID = "t3-connect-bridge";
var BridgeConfig = Schema.Struct({
  relayUrl: Schema.String.pipe(Schema.withDecodingDefault(Effect.succeed("https://relay.t3.codes"))),
  clerkPublishableKey: Schema.String.pipe(Schema.withDecodingDefault(Effect.succeed("pk_live_Y2xlcmsudDMuY29kZXMk"))),
  cliOAuthClientId: Schema.String.pipe(Schema.withDecodingDefault(Effect.succeed("hzxSgY2cH10sDU2r"))),
  hostedAppUrl: Schema.String.pipe(Schema.withDecodingDefault(Effect.succeed("https://app.t3.codes"))),
  pushNotifications: Schema.Boolean.pipe(Schema.withDecodingDefault(Effect.succeed(true)))
});
var BridgeTunnelState = Schema.Literals(["off", "starting", "connected", "failed"]);
var BridgeStatus = Schema.Struct({
  account: Schema.NullOr(Schema.String),
  signedIn: Schema.Boolean,
  pendingSignIn: Schema.NullOr(Schema.Struct({
    verificationUrl: Schema.String,
    userCode: Schema.String
  })),
  linked: Schema.Boolean,
  tunnel: BridgeTunnelState,
  hostname: Schema.NullOr(Schema.String),
  error: Schema.NullOr(Schema.String),
  config: BridgeConfig
});
var NoInput = Schema.Struct({});
var BridgeConfigPatch = Schema.Struct({
  relayUrl: Schema.optionalKey(Schema.String),
  clerkPublishableKey: Schema.optionalKey(Schema.String),
  cliOAuthClientId: Schema.optionalKey(Schema.String),
  hostedAppUrl: Schema.optionalKey(Schema.String),
  pushNotifications: Schema.optionalKey(Schema.Boolean)
});
var bridgeActions = {
  status: { input: NoInput, output: BridgeStatus },
  signIn: { input: NoInput, output: BridgeStatus },
  signOut: { input: NoInput, output: BridgeStatus },
  link: { input: NoInput, output: BridgeStatus },
  unlink: { input: NoInput, output: BridgeStatus },
  setConfig: { input: BridgeConfigPatch, output: BridgeStatus }
};

// src/bridge.ts
import { PluginContext, PluginError as PluginError5 } from "@t3tools/plugin-api";
import * as Clock2 from "effect/Clock";
import * as SecureRandom from "effect/crypto/SecureRandom";
import * as DateTime from "effect/DateTime";
import * as Duration2 from "effect/Duration";
import * as Effect8 from "effect/Effect";
import * as Exit from "effect/Exit";
import * as Fiber from "effect/Fiber";
import * as HttpClient7 from "effect/http/HttpClient";
import * as HttpClientResponse4 from "effect/http/HttpClientResponse";
import * as Option4 from "effect/Option";
import * as Ref from "effect/Ref";
import * as Schema7 from "effect/Schema";
import * as Schedule from "effect/Schedule";
import * as Scope from "effect/Scope";
import * as Semaphore from "effect/Semaphore";

// src/routeIngress.ts
import * as NodeHttp from "node:http";
import * as NodeNet from "node:net";
import { PluginError } from "@t3tools/plugin-api";
import * as Effect2 from "effect/Effect";

// src/relayProtocol.ts
import { EnvironmentId, ThreadId, TrimmedNonEmptyString } from "@t3tools/contracts";
import * as Schema2 from "effect/Schema";
var RELAY_LINK_PROOF_TYP = "t3-env-link+jwt";
var RELAY_MINT_REQUEST_TYP = "t3-cloud-mint+jwt";
var RELAY_HEALTH_REQUEST_TYP = "t3-cloud-health+jwt";
var RELAY_MINT_RESPONSE_TYP = "t3-env-mint+jwt";
var RELAY_HEALTH_RESPONSE_TYP = "t3-env-health+jwt";
var RELAY_ACTIVITY_PUBLISH_TYP = "t3-env-activity+jwt";
var HEALTH_ROUTE = "/api/t3-connect/health";
var MINT_ROUTE = "/api/t3-connect/mint-credential";
var ManagedEndpoint = Schema2.Struct({
  httpBaseUrl: TrimmedNonEmptyString,
  wsBaseUrl: TrimmedNonEmptyString,
  providerKind: Schema2.Literals(["manual", "cloudflare_tunnel", "t3_relay"])
});
var ManagedEndpointOrigin = Schema2.Struct({
  localHttpHost: TrimmedNonEmptyString,
  localHttpPort: Schema2.Int.check(Schema2.isGreaterThanOrEqualTo(1), Schema2.isLessThanOrEqualTo(65535))
});
var ManagedEndpointRuntimeConfig = Schema2.Struct({
  providerKind: Schema2.Literals(["manual", "cloudflare_tunnel", "t3_relay"]),
  connectorToken: TrimmedNonEmptyString,
  tunnelId: Schema2.optional(TrimmedNonEmptyString),
  tunnelName: Schema2.optional(TrimmedNonEmptyString)
});
var LinkChallengeResponse = Schema2.Struct({
  challenge: TrimmedNonEmptyString,
  expiresAt: TrimmedNonEmptyString
});
var LinkResponse = Schema2.Struct({
  ok: Schema2.Boolean,
  cloudUserId: TrimmedNonEmptyString,
  environmentId: EnvironmentId,
  endpoint: ManagedEndpoint,
  endpointRuntime: Schema2.NullOr(ManagedEndpointRuntimeConfig),
  relayIssuer: TrimmedNonEmptyString,
  environmentCredential: TrimmedNonEmptyString,
  cloudMintPublicKey: TrimmedNonEmptyString
});
var OkResponse = Schema2.Struct({ ok: Schema2.Boolean });
var RegisteredClaims = {
  iss: TrimmedNonEmptyString,
  aud: TrimmedNonEmptyString,
  sub: TrimmedNonEmptyString,
  jti: TrimmedNonEmptyString,
  iat: Schema2.Int,
  exp: Schema2.Int
};
var MintCredentialProofPayload = Schema2.Struct({
  ...RegisteredClaims,
  environmentId: EnvironmentId,
  clientProofKeyThumbprint: TrimmedNonEmptyString,
  cnf: Schema2.Struct({ jkt: TrimmedNonEmptyString }),
  deviceId: Schema2.optional(TrimmedNonEmptyString),
  nonce: TrimmedNonEmptyString,
  scope: Schema2.Array(Schema2.Literal("environment:connect"))
});
var HealthProofPayload = Schema2.Struct({
  ...RegisteredClaims,
  environmentId: EnvironmentId,
  nonce: TrimmedNonEmptyString,
  scope: Schema2.Array(Schema2.Literal("environment:status"))
});
var ProofRequest = Schema2.Struct({ proof: TrimmedNonEmptyString });
var AgentActivityState = Schema2.Struct({
  environmentId: EnvironmentId,
  threadId: ThreadId,
  projectTitle: TrimmedNonEmptyString,
  threadTitle: TrimmedNonEmptyString,
  phase: Schema2.Literals([
    "starting",
    "running",
    "waiting_for_approval",
    "waiting_for_input",
    "completed",
    "failed",
    "stale"
  ]),
  headline: TrimmedNonEmptyString,
  detail: Schema2.optional(TrimmedNonEmptyString),
  modelTitle: TrimmedNonEmptyString,
  updatedAt: TrimmedNonEmptyString,
  deepLink: TrimmedNonEmptyString
});
var PublishResponse = Schema2.Struct({ ok: Schema2.Boolean });
var RelayErrorBody = Schema2.Struct({
  _tag: Schema2.String,
  reason: Schema2.optional(Schema2.String),
  traceId: Schema2.optional(Schema2.String)
});

// src/routeIngress.ts
function routeUrl(origin, path, secret) {
  const url = new URL(origin);
  const incoming = new URL(path, "http://ingress.invalid");
  url.pathname = incoming.pathname;
  url.search = incoming.search;
  if (url.pathname === HEALTH_ROUTE || url.pathname === MINT_ROUTE) {
    url.searchParams.set("p0_route", secret);
  }
  return url;
}
var makeRouteIngress = (origin, secret) => Effect2.acquireRelease(Effect2.callback((resume) => {
  const target = new URL(origin);
  const sockets = new Set;
  const server = NodeHttp.createServer((request2, response) => {
    let url;
    try {
      url = routeUrl(origin, request2.url ?? "/", secret);
    } catch {
      response.writeHead(400);
      response.end();
      return;
    }
    const upstream = NodeHttp.request(url, {
      method: request2.method,
      headers: request2.headers
    }, (incoming) => {
      response.writeHead(incoming.statusCode ?? 502, incoming.headers);
      incoming.pipe(response);
      incoming.on("error", () => response.destroy());
    });
    upstream.on("error", () => {
      if (response.headersSent) {
        response.destroy();
        return;
      }
      response.writeHead(502);
      response.end();
    });
    request2.on("aborted", () => upstream.destroy());
    response.on("close", () => upstream.destroy());
    request2.pipe(upstream);
  });
  server.on("upgrade", (request2, socket, head) => {
    const upstream = NodeNet.connect(Number(target.port || 80), target.hostname.replace(/^\[(.*)\]$/u, "$1"));
    upstream.on("connect", () => {
      upstream.write(`${request2.method} ${request2.url} HTTP/${request2.httpVersion}\r
`);
      for (let i = 0;i < request2.rawHeaders.length; i += 2) {
        upstream.write(`${request2.rawHeaders[i]}: ${request2.rawHeaders[i + 1]}\r
`);
      }
      upstream.write(`\r
`);
      upstream.write(head);
      socket.pipe(upstream);
      upstream.pipe(socket);
    });
    upstream.on("error", () => socket.destroy());
    socket.on("error", () => upstream.destroy());
    socket.on("close", () => upstream.destroy());
  });
  server.on("connection", (socket) => {
    sockets.add(socket);
    socket.on("close", () => sockets.delete(socket));
  });
  server.once("error", () => resume(Effect2.fail(new PluginError({ message: "Could not start the T3 Connect ingress." }))));
  server.listen(0, "127.0.0.1", () => {
    const address = server.address();
    if (address !== null && typeof address !== "string") {
      resume(Effect2.succeed({ server, origin: `http://127.0.0.1:${address.port}`, sockets }));
    }
  });
  return Effect2.sync(() => server.close());
}), ({ server, sockets }) => Effect2.sync(() => {
  for (const socket of sockets)
    socket.destroy();
  server.closeAllConnections();
  server.close();
})).pipe(Effect2.map((ingress) => ingress.origin));

// src/cloudflared.ts
import { PluginError as PluginError2 } from "@t3tools/plugin-api";

// ../../packages/shared/src/HostProcess.ts
import * as Context from "effect/Context";
import * as Effect3 from "effect/Effect";
import * as Schema3 from "effect/Schema";
import * as NodeDns from "node:dns";
import * as NodeOS from "node:os";
import * as NodeSea from "node:sea";
var Platform = Context.Reference("@t3tools/shared/HostProcess/Platform", {
  defaultValue: () => process.platform
});
var Architecture = Context.Reference("@t3tools/shared/HostProcess/Architecture", {
  defaultValue: () => process.arch
});
var KernelRelease = Context.Reference("@t3tools/shared/HostProcess/KernelRelease", {
  defaultValue: () => NodeOS.release()
});
var LinuxLibc = Context.Reference("@t3tools/shared/HostProcess/LinuxLibc", {
  defaultValue: () => {
    try {
      const report = process.report?.getReport();
      return typeof report?.header?.glibcVersionRuntime === "string" ? "gnu" : "musl";
    } catch {
      return "musl";
    }
  }
});
var Hostname = Context.Reference("@t3tools/shared/HostProcess/Hostname", {
  defaultValue: () => NodeOS.hostname()
});
var Username = Context.Reference("@t3tools/shared/HostProcess/Username", {
  defaultValue: () => {
    try {
      return NodeOS.userInfo().username.trim() || null;
    } catch {
      return null;
    }
  }
});
var HomeDirectory = Context.Reference("@t3tools/shared/HostProcess/HomeDirectory", {
  defaultValue: () => NodeOS.homedir()
});
var Environment = Context.Reference("@t3tools/shared/HostProcess/Environment", {
  defaultValue: () => process.env
});
var WorkingDirectory = Context.Reference("@t3tools/shared/HostProcess/WorkingDirectory", {
  defaultValue: () => process.cwd()
});
var ExecutablePath = Context.Reference("@t3tools/shared/HostProcess/ExecutablePath", {
  defaultValue: () => process.execPath
});
var Arguments = Context.Reference("@t3tools/shared/HostProcess/Arguments", {
  defaultValue: () => process.argv
});
var InvokedAs = Context.Reference("@t3tools/shared/HostProcess/InvokedAs", {
  defaultValue: () => process.argv0
});
var IsExecutable = Context.Reference("@t3tools/shared/HostProcess/IsExecutable", {
  defaultValue: () => NodeSea.isSea()
});

class HostnameLookupError extends Schema3.TaggedError()("HostnameLookupError", { hostname: Schema3.String, cause: Schema3.Defect() }) {
  get message() {
    return `Could not resolve ${this.hostname}.`;
  }
}
var Addresses = Context.Reference("@t3tools/shared/HostProcess/Addresses", {
  defaultValue: Effect3.fnUntraced(function* () {
    const interfaces = Object.values(NodeOS.networkInterfaces()).flat().flatMap((entry) => entry ? [entry.address] : []);
    const hostname2 = NodeOS.hostname();
    const resolved = yield* Effect3.tryPromise({
      try: () => NodeDns.promises.lookup(hostname2, { all: true }),
      catch: (cause) => new HostnameLookupError({ hostname: hostname2, cause })
    }).pipe(Effect3.map((entries) => entries.map((entry) => entry.address)), Effect3.orElseSucceed(() => []));
    return new Set([...interfaces, ...resolved]);
  })
});
var UserId = Context.Reference("@t3tools/shared/HostProcess/UserId", {
  defaultValue: () => process.getuid?.()
});
var isWindows = Effect3.map(Platform, (platform) => platform === "win32");

// src/cloudflared.ts
import * as Config from "effect/Config";
import * as Digest from "effect/crypto/Digest";
import * as Effect4 from "effect/Effect";
import * as Hex from "effect/encoding/Hex";
import * as FileSystem from "effect/FileSystem";
import * as HttpClient from "effect/http/HttpClient";
import * as HttpClientResponse from "effect/http/HttpClientResponse";
import * as Option from "effect/Option";
import * as Path from "effect/Path";
import * as ChildProcess from "effect/process/ChildProcess";
import * as ChildProcessSpawner from "effect/process/ChildProcessSpawner";
import * as Stream from "effect/Stream";
var CLOUDFLARED_VERSION = "2026.10.4";
var RELEASE = `https://github.com/cloudflare/cloudflared/releases/download/${CLOUDFLARED_VERSION}`;
var WINDOWS_X64 = {
  url: `${RELEASE}/cloudflared-windows-amd64.exe`,
  sha256: "411b16d40c8d872243efeb52c550053d00af0a8a97fbb32e730fb8aba429eaa8",
  archive: "binary"
};
var RELEASE_ASSETS = {
  "darwin-arm64": {
    url: `${RELEASE}/cloudflared-darwin-arm64.tgz`,
    sha256: "68b6bc4080ac1330234db2a9002d07f98b000537a1bd531a687b660d4160fa7f",
    archive: "tgz"
  },
  "darwin-x64": {
    url: `${RELEASE}/cloudflared-darwin-amd64.tgz`,
    sha256: "f11fbef4207d715892331917dafd437f032cf4b7137ed64dea3008338c1c613d",
    archive: "tgz"
  },
  "linux-arm64": {
    url: `${RELEASE}/cloudflared-linux-arm64`,
    sha256: "2b7203b4fb0ba28a0c1e12f8855ce2c25f76d266a8d5edafac5540b6812acff6",
    archive: "binary"
  },
  "linux-x64": {
    url: `${RELEASE}/cloudflared-linux-amd64`,
    sha256: "ae5e8add7884b0531d66bbca4570d1de491ff6da51e4ebe7eb160cdf241d9e42",
    archive: "binary"
  },
  "win32-x64": WINDOWS_X64,
  "win32-arm64": WINDOWS_X64
};
var METRICS_LINE = /\bStarting metrics server on (127\.0\.0\.1:\d+)\/metrics\b/u;
function classifyConnectorLine(line) {
  if (/\bRegistered tunnel connection\b/iu.test(line))
    return "connected";
  if (/\bRegister tunnel error from server side\b/iu.test(line) && /error="(?:Unauthorized:[^"]*|Failed to get tunnel|Tunnel not found|Record for tunnel not found|Invalid tunnel secret)"/iu.test(line)) {
    return "rejected";
  }
  return METRICS_LINE.test(line) ? "metrics" : "other";
}
var installError = (message) => (cause) => new PluginError2({ message, cause });
var ensureCloudflared = Effect4.fn("bridge.cloudflared.ensure")(function* (dataDir) {
  const override = yield* Config.String("T3CODE_CLOUDFLARED_PATH").pipe(Config.option);
  if (Option.isSome(override) && override.value.trim())
    return override.value.trim();
  const fs = yield* FileSystem.FileSystem;
  const path = yield* Path.Path;
  const platform = yield* Platform;
  const arch = yield* Architecture;
  const asset = RELEASE_ASSETS[`${platform}-${arch}`];
  if (asset === undefined) {
    return yield* new PluginError2({
      message: `T3 Connect's tunnel has no build for ${platform}-${arch}.`
    });
  }
  const dir = path.join(dataDir, `cloudflared-${CLOUDFLARED_VERSION}`);
  const executable = path.join(dir, platform === "win32" ? "cloudflared.exe" : "cloudflared");
  if (yield* fs.exists(executable).pipe(Effect4.orElseSucceed(() => false)))
    return executable;
  yield* Effect4.logInfo("Downloading cloudflared for T3 Connect", { version: CLOUDFLARED_VERSION });
  const client = yield* HttpClient.HttpClient;
  const bytes = yield* client.get(asset.url).pipe(Effect4.flatMap(HttpClientResponse.filterStatusOk), Effect4.flatMap((response) => response.arrayBuffer), Effect4.map((buffer) => new Uint8Array(buffer)), Effect4.timeout("10 minutes"), Effect4.mapError(installError("Could not download cloudflared.")));
  const digest = yield* Digest.Digest;
  const sha2562 = Hex.encode(yield* digest.digest(Digest.sha256, bytes).pipe(Effect4.mapError(installError("Could not hash cloudflared."))));
  if (sha2562 !== asset.sha256) {
    return yield* new PluginError2({ message: "The cloudflared download failed its checksum." });
  }
  const staging = `${dir}.partial`;
  yield* fs.remove(staging, { recursive: true }).pipe(Effect4.ignore);
  yield* fs.makeDirectory(staging, { recursive: true }).pipe(Effect4.mapError(installError("Could not install cloudflared.")));
  const stagedExecutable = path.join(staging, path.basename(executable));
  if (asset.archive === "tgz") {
    const archive = path.join(staging, "cloudflared.tgz");
    yield* fs.writeFile(archive, bytes).pipe(Effect4.mapError(installError("Could not install cloudflared.")));
    const spawner = yield* ChildProcessSpawner.ChildProcessSpawner;
    const exitCode = yield* spawner.exitCode(ChildProcess.make("tar", ["-xzf", archive, "-C", staging], { shell: false })).pipe(Effect4.mapError(installError("Could not unpack cloudflared.")));
    if (exitCode !== 0)
      return yield* new PluginError2({ message: "Could not unpack cloudflared." });
    yield* fs.remove(archive).pipe(Effect4.ignore);
  } else {
    yield* fs.writeFile(stagedExecutable, bytes).pipe(Effect4.mapError(installError("Could not install cloudflared.")));
  }
  yield* fs.chmod(stagedExecutable, 493).pipe(Effect4.mapError(installError("Could not install cloudflared.")));
  yield* fs.rename(staging, dir).pipe(Effect4.mapError(installError("Could not install cloudflared.")));
  return executable;
});
var spawnConnector = Effect4.fn("bridge.cloudflared.spawn")(function* (input) {
  const spawner = yield* ChildProcessSpawner.ChildProcessSpawner;
  const child = yield* spawner.spawn(ChildProcess.make(input.executable, [
    "tunnel",
    "--no-autoupdate",
    "--loglevel",
    "info",
    "--output",
    "default",
    "--metrics",
    "127.0.0.1:0",
    "run"
  ], {
    detached: false,
    shell: false,
    env: { ...yield* Environment, TUNNEL_TOKEN: input.connectorToken },
    stdout: "pipe",
    stderr: "pipe"
  }));
  yield* child.all.pipe(Stream.decodeText(), Stream.splitLines, Stream.map((line) => line.trim()), Stream.filter((line) => line.length > 0), Stream.runForEach((line) => input.onLine(line.replaceAll(input.connectorToken, "<redacted>"))), Effect4.ignore, Effect4.forkScoped);
  return child;
}, Effect4.mapError(installError("Could not start cloudflared.")));

// src/jwt.ts
import { PluginError as PluginError3 } from "@t3tools/plugin-api";
import * as Effect5 from "effect/Effect";
import * as Jwk from "effect/jose/Jwk";
import * as Jws from "effect/jose/Jws";
import * as Jwt from "effect/jose/Jwt";
import * as Redacted from "effect/Redacted";
import * as Schema4 from "effect/Schema";
var normalizeIssuer = (value2) => value2.trim().replace(/\/+$/u, "");
var normalizePem = (value2) => value2.replace(/\\n/gu, `
`).trim();
var KeyPair = Schema4.Struct({ privateKey: Schema4.String, publicKey: Schema4.String });
var generateKeyPair2 = Jwk.generateKeyPair({ algorithm: "EdDSA" }).pipe(Effect5.flatMap((pair) => Effect5.all({
  privateKey: Jwk.importPrivate(pair.privateKey, "EdDSA").pipe(Effect5.flatMap((key) => Jwk.exportPkcs8(key, { format: "pem" })), Effect5.map(Redacted.value)),
  publicKey: Jwk.importPublic(pair.publicKey, "EdDSA").pipe(Effect5.flatMap((key) => Jwk.exportSpki(key, { format: "pem" })))
})), Effect5.mapError((cause) => new PluginError3({ message: "Could not create a signing key.", cause })));
var signJwt = (input) => Jwk.importPkcs8(Redacted.make(normalizePem(input.privateKeyPem)), "EdDSA").pipe(Effect5.flatMap((key) => Jws.sign(new TextEncoder().encode(JSON.stringify(input.payload)), key, { typ: input.typ })), Effect5.map(Redacted.value), Effect5.mapError((cause) => new PluginError3({ message: "Could not sign a T3 Connect proof.", cause })));
var verifyJwt = (schema, input) => Jwk.importSpki(normalizePem(input.publicKeyPem), "EdDSA").pipe(Effect5.flatMap((key) => Jwt.verify(schema, input.token, key, {
  typ: input.typ,
  issuer: input.issuer,
  audience: input.audience,
  maxTokenAge: "5 minutes",
  clockTolerance: "60 seconds"
})), Effect5.map((verified) => verified.claims));
var unverifiedIssuedAt = (token) => Jwt.decodeUnverified(token).pipe(Effect5.map(({ claims }) => typeof claims.iat === "number" && Number.isSafeInteger(claims.iat) && claims.iat > 0 ? claims.iat : null), Effect5.orElseSucceed(() => null));
var isValidPublicKey = (pem) => Jwk.importSpki(normalizePem(pem), "EdDSA").pipe(Effect5.as(true), Effect5.orElseSucceed(() => false));
var MAX_PROOF_LIFETIME_SECONDS = 5 * 60;
var CLOCK_SKEW_SECONDS = 60;
function hasBoundedLifetime(input) {
  return input.exp > input.iat && input.exp - input.iat <= MAX_PROOF_LIFETIME_SECONDS && input.iat <= input.nowSeconds + CLOCK_SKEW_SECONDS;
}
function hasExactScope(scopes, expected) {
  return scopes.length === 1 && scopes[0] === expected;
}

// src/oauth.ts
import { PluginError as PluginError4 } from "@t3tools/plugin-api";
import * as Clock from "effect/Clock";
import * as Duration from "effect/Duration";
import * as Effect6 from "effect/Effect";
import * as Base64Url from "effect/encoding/Base64Url";
import * as Option2 from "effect/Option";
import * as Schema5 from "effect/Schema";
import * as HttpClient3 from "effect/http/HttpClient";
import * as HttpClientRequest from "effect/http/HttpClientRequest";
import * as HttpClientResponse2 from "effect/http/HttpClientResponse";
var isPluginError = Schema5.is(PluginError4);
var SCOPES = "openid profile email offline_access";
var DEVICE_CODE_GRANT = "urn:ietf:params:oauth:grant-type:device_code";
var REQUEST_TIMEOUT = Duration.seconds(10);
var REFRESH_EARLY_MS = 5 * 60000;
var StoredToken = Schema5.Struct({
  accessToken: Schema5.String,
  refreshToken: Schema5.String,
  expiresAtEpochMs: Schema5.Number,
  identity: Schema5.NullOr(Schema5.String)
});
var TokenResponse = Schema5.Struct({
  access_token: Schema5.String,
  refresh_token: Schema5.optional(Schema5.String),
  id_token: Schema5.optional(Schema5.String),
  expires_in: Schema5.Number
});
var ErrorResponse = Schema5.Struct({ error: Schema5.String });
var DeviceAuthorizationResponse = Schema5.Struct({
  device_code: Schema5.String,
  user_code: Schema5.String,
  verification_uri: Schema5.String,
  verification_uri_complete: Schema5.optional(Schema5.String),
  expires_in: Schema5.Number,
  interval: Schema5.optional(Schema5.Number)
});
function clerkFrontendApiUrl(publishableKey) {
  const encoded = publishableKey.trim().split("_").slice(2).join("_");
  try {
    const host = globalThis.atob(encoded).replace(/\$$/u, "");
    if (host.length === 0 || host.includes("/"))
      return null;
    return new URL(`https://${host}`).origin;
  } catch {
    return null;
  }
}
var endpoints = (config) => {
  const base = clerkFrontendApiUrl(config.clerkPublishableKey);
  return base === null ? Effect6.fail(new PluginError4({ message: "The Clerk publishable key is not valid." })) : Effect6.succeed({
    token: `${base}/oauth/token`,
    deviceAuthorization: `${base}/oauth/device_authorization`
  });
};
function identityFromIdToken(idToken) {
  const payload = idToken?.split(".")[1];
  if (!payload)
    return null;
  const decoded = Base64Url.decodeString(payload);
  if (decoded._tag !== "Success")
    return null;
  try {
    const claims = JSON.parse(decoded.success);
    if (typeof claims !== "object" || claims === null)
      return null;
    for (const key of ["email", "preferred_username", "sub"]) {
      const value2 = Reflect.get(claims, key);
      if (typeof value2 === "string" && value2.length > 0)
        return value2;
    }
  } catch {
    return null;
  }
  return null;
}
var toStoredToken = (body, previous) => Clock.currentTimeMillis.pipe(Effect6.map((now) => ({
  accessToken: body.access_token,
  refreshToken: body.refresh_token ?? previous?.refreshToken ?? "",
  expiresAtEpochMs: now + body.expires_in * 1000,
  identity: identityFromIdToken(body.id_token) ?? previous?.identity ?? null
})));
var postForm = (url, params) => HttpClient3.HttpClient.pipe(Effect6.flatMap((client) => client.execute(HttpClientRequest.post(url).pipe(HttpClientRequest.bodyUrlParams(params)))), Effect6.timeout(REQUEST_TIMEOUT));
var startDeviceAuthorization = Effect6.fn("bridge.oauth.startDevice")(function* (config) {
  const urls = yield* endpoints(config);
  const response = yield* postForm(urls.deviceAuthorization, {
    client_id: config.cliOAuthClientId,
    scope: SCOPES
  }).pipe(Effect6.flatMap(HttpClientResponse2.filterStatusOk), Effect6.flatMap(HttpClientResponse2.schemaBodyJson(DeviceAuthorizationResponse)));
  return {
    deviceCode: response.device_code,
    userCode: response.user_code,
    verificationUrl: response.verification_uri_complete ?? response.verification_uri,
    expiresIn: Duration.seconds(response.expires_in),
    interval: Duration.seconds(response.interval ?? 5)
  };
}, Effect6.mapError((cause) => isPluginError(cause) ? cause : new PluginError4({ message: "Could not reach T3 Connect sign-in.", cause })));
var pollDeviceToken = Effect6.fn("bridge.oauth.pollDevice")(function* (config, authorization) {
  const urls = yield* endpoints(config);
  let interval = authorization.interval;
  while (true) {
    yield* Effect6.sleep(interval);
    const response = yield* postForm(urls.token, {
      grant_type: DEVICE_CODE_GRANT,
      device_code: authorization.deviceCode,
      client_id: config.cliOAuthClientId
    }).pipe(Effect6.option);
    if (Option2.isNone(response) || response.value.status >= 500) {
      interval = Duration.sum(interval, Duration.seconds(5));
      continue;
    }
    if (response.value.status < 300) {
      const body = yield* HttpClientResponse2.schemaBodyJson(TokenResponse)(response.value);
      return yield* toStoredToken(body);
    }
    const failure = yield* HttpClientResponse2.schemaBodyJson(ErrorResponse)(response.value);
    if (failure.error === "authorization_pending")
      continue;
    if (failure.error === "slow_down") {
      interval = Duration.sum(interval, Duration.seconds(5));
      continue;
    }
    return yield* new PluginError4({
      message: failure.error === "access_denied" ? "Sign-in was denied." : failure.error === "expired_token" ? "The sign-in code expired." : `Sign-in failed (${failure.error}).`
    });
  }
}, (effect, _config, authorization) => effect.pipe(Effect6.timeoutOrElse({
  duration: authorization.expiresIn,
  orElse: () => Effect6.fail(new PluginError4({ message: "The sign-in code expired." }))
})), Effect6.mapError((cause) => isPluginError(cause) ? cause : new PluginError4({ message: "Could not finish T3 Connect sign-in.", cause })));
var refreshIfNeeded = Effect6.fn("bridge.oauth.refresh")(function* (config, token) {
  const now = yield* Clock.currentTimeMillis;
  if (token.expiresAtEpochMs - REFRESH_EARLY_MS > now)
    return Option2.some(token);
  const urls = yield* endpoints(config);
  const response = yield* postForm(urls.token, {
    grant_type: "refresh_token",
    refresh_token: token.refreshToken,
    client_id: config.cliOAuthClientId
  }).pipe(Effect6.mapError((cause) => new PluginError4({ message: "Could not reach T3 Connect sign-in.", cause })));
  if (response.status >= 400 && response.status < 500 && response.status !== 429) {
    return Option2.none();
  }
  const body = yield* HttpClientResponse2.filterStatusOk(response).pipe(Effect6.flatMap(HttpClientResponse2.schemaBodyJson(TokenResponse)), Effect6.mapError((cause) => new PluginError4({ message: "Could not refresh the T3 Connect sign-in.", cause })));
  return Option2.some(yield* toStoredToken(body, token));
});

// src/relay.ts
import * as Effect7 from "effect/Effect";
import * as Option3 from "effect/Option";
import * as Schema6 from "effect/Schema";
import * as HttpClient5 from "effect/http/HttpClient";
import * as HttpClientRequest2 from "effect/http/HttpClientRequest";
import * as HttpClientResponse3 from "effect/http/HttpClientResponse";
class RelayRequestError extends Schema6.TaggedError()("RelayRequestError", {
  rejection: Schema6.Literals(["unauthorized", "rejected", "unavailable"]),
  message: Schema6.String
}) {
}
var isRelayRequestError = Schema6.is(RelayRequestError);
function normalizeRelayUrl(value2) {
  try {
    const url = new URL(value2.trim());
    if (url.protocol !== "https:" || url.username !== "" || url.password !== "" || url.search !== "" || url.hash !== "" || !/^\/*$/u.test(url.pathname)) {
      return null;
    }
    return url.origin;
  } catch {
    return null;
  }
}
function parseLocalOrigin(localOrigin) {
  const url = new URL(localOrigin);
  const ws = new URL(url.origin);
  ws.protocol = url.protocol === "https:" ? "wss:" : "ws:";
  return {
    httpBaseUrl: url.origin,
    wsBaseUrl: ws.origin,
    origin: {
      localHttpHost: url.hostname.replace(/^\[(.*)\]$/u, "$1"),
      localHttpPort: Number(url.port || (url.protocol === "https:" ? 443 : 80))
    }
  };
}
var REFUSAL_TEXT = {
  environment_key_mismatch: "This environment is already linked with a different key — Unlink it here and link again, or restore the old key",
  invalid_signature_or_scope: "T3 Connect rejected this machine's proof signature or scopes — Sign in again, then Link",
  descriptor_mismatch: "T3 Connect rejected this machine's descriptor — update p0code, then Link",
  replayed_nonce: "T3 Connect has seen this proof before — Link again",
  challenge_invalid: "The link challenge expired or was already used — Link again",
  origin_not_allowed: "T3 Connect does not allow this machine's origin",
  endpoint_not_secure: "The tunnel endpoint must be HTTPS"
};
function describeRefusal(error) {
  const code = `${error._tag}${error.reason === undefined ? "" : `: ${error.reason}`}` + `${error.traceId === undefined ? "" : `, trace ${error.traceId}`}`;
  const advice = error.reason === undefined ? undefined : REFUSAL_TEXT[error.reason];
  return advice === undefined ? `T3 Connect refused the request (${code}).` : `${advice} (${code}).`;
}
var describeFailure = Effect7.fn("bridge.relay.describeFailure")(function* (response) {
  const body = yield* HttpClientResponse3.schemaBodyJson(RelayErrorBody)(response).pipe(Effect7.option);
  const limitExceeded = Option3.isSome(body) && body.value._tag === "RelayEnvironmentLinkLimitExceededError";
  const expired = Option3.isSome(body) && body.value._tag.includes("Expired");
  return new RelayRequestError({
    rejection: response.status === 401 && !expired ? "unauthorized" : response.status >= 400 && response.status < 500 && response.status !== 408 && response.status !== 429 && !expired ? "rejected" : "unavailable",
    message: limitExceeded ? 'Your T3 Connect account has reached its linked-environment limit. Unlink an unused machine in T3 Code (or migrate with "Keep environment ID" enabled) and try again.' : Option3.isSome(body) ? describeRefusal(body.value) : `T3 Connect refused the request (HTTP ${response.status}).`
  });
});
var relayRequest = Effect7.fn("bridge.relay.request")(function* (input) {
  const client = yield* HttpClient5.HttpClient;
  const base = (input.method === "POST" ? HttpClientRequest2.post : HttpClientRequest2.delete)(input.url).pipe(HttpClientRequest2.bearerToken(input.bearer));
  const request2 = input.body === undefined ? base : yield* HttpClientRequest2.bodyJson(base, input.body);
  const response = yield* client.execute(request2);
  if (response.status < 200 || response.status >= 300) {
    return yield* yield* describeFailure(response);
  }
  return yield* HttpClientResponse3.schemaBodyJson(input.schema)(response);
}, (effect, input) => effect.pipe(Effect7.timeout(input.timeout ?? "10 seconds")), Effect7.mapError((cause) => isRelayRequestError(cause) ? cause : new RelayRequestError({
  rejection: "unavailable",
  message: "Could not reach T3 Connect. Check this machine's network connection."
})));

// src/bridge.ts
var StoredLink = Schema7.Struct({
  relayUrl: Schema7.String,
  relayIssuer: Schema7.String,
  cloudUserId: Schema7.String,
  environmentCredential: Schema7.String,
  cloudMintPublicKey: Schema7.String,
  endpointRuntime: Schema7.NullOr(ManagedEndpointRuntimeConfig)
});
var KEYS = {
  config: "config",
  token: "token",
  link: "link",
  signingKey: "signing-key",
  wantLinked: "want-linked"
};
var DEFAULT_CONFIG = Schema7.decodeSync(BridgeConfig)({});
var decodeProofRequest = Schema7.decodeUnknownOption(ProofRequest);
var RECOVERY_COOLDOWN = Duration2.minutes(2);
var RECOVERY_MAX_COOLDOWN = Duration2.minutes(30);
var REJECTIONS_BEFORE_RELINK = 4;
var ConnectorConfigBody = Schema7.Struct({
  config: Schema7.Struct({
    ingress: Schema7.optional(Schema7.NullOr(Schema7.Array(Schema7.Struct({ hostname: Schema7.optional(Schema7.String) }))))
  })
});
var isPluginError2 = Schema7.is(PluginError5);
var toPluginError = (error) => isPluginError2(error) ? error : new PluginError5({ message: error.message });
var uuid = SecureRandom.SecureRandom.pipe(Effect8.flatMap((random) => random.uuidV4()));
var isoFromSeconds = (seconds2) => DateTime.formatIso(DateTime.makeUnsafe(seconds2 * 1000));
function makeReplayGuard() {
  const seen = new Map;
  return (keys, nowMs) => {
    for (const [key, expiresAt] of seen)
      if (expiresAt <= nowMs)
        seen.delete(key);
    if (keys.some((key) => seen.has(key)))
      return false;
    for (const key of keys)
      seen.set(key, nowMs + 10 * 60000);
    return true;
  };
}
var makeBridge = Effect8.fn("bridge.make")(function* (onLinked) {
  const ctx = yield* PluginContext;
  const services = yield* Effect8.context();
  const provided = (effect) => effect.pipe(Effect8.provideContext(services));
  const pluginScope = yield* Effect8.scope;
  const ingressOrigin = yield* Effect8.cached(Effect8.gen(function* () {
    if (ctx.routes === undefined) {
      return yield* new PluginError5({
        message: "The host did not provide a plugin route secret."
      });
    }
    return yield* makeRouteIngress(yield* ctx.environment.localOrigin, ctx.routes.secret).pipe(Scope.provide(pluginScope));
  }));
  const state = yield* Ref.make({
    pendingSignIn: null,
    tunnel: "off",
    hostname: null,
    error: null
  });
  const linkLock = yield* Semaphore.make(1);
  const consumeReplay = makeReplayGuard();
  let tunnelScope = null;
  let signInFiber = null;
  let lastRecoveryAt = Number.NEGATIVE_INFINITY;
  let recoveryCooldown = RECOVERY_COOLDOWN;
  const readJson = (key, schema) => ctx.storage.get(key).pipe(Effect8.map(Option4.flatMap(Schema7.decodeUnknownOption(Schema7.fromJsonString(schema)))));
  const writeJson = (key, schema, value2) => Schema7.encodeEffect(Schema7.fromJsonString(schema))(value2).pipe(Effect8.mapError((cause) => new PluginError5({ message: "Could not save T3 Connect state.", cause })), Effect8.flatMap((json) => ctx.storage.set(key, json)));
  const readConfig = readJson(KEYS.config, BridgeConfig).pipe(Effect8.map(Option4.getOrElse(() => DEFAULT_CONFIG)));
  const readLink = readJson(KEYS.link, StoredLink).pipe(Effect8.map(Option4.getOrNull));
  const signingKey = Effect8.gen(function* () {
    const existing = yield* readJson(KEYS.signingKey, KeyPair);
    if (Option4.isSome(existing))
      return existing.value;
    const created = yield* generateKeyPair2;
    yield* writeJson(KEYS.signingKey, KeyPair, created);
    return created;
  });
  const setState = (update2) => Ref.update(state, (current) => ({ ...current, ...update2 })).pipe(Effect8.andThen(publishStatus));
  const status = Effect8.gen(function* () {
    const [config, token, link2, runtime] = yield* Effect8.all([
      readConfig,
      readJson(KEYS.token, StoredToken),
      readLink,
      Ref.get(state)
    ]);
    return {
      account: Option4.isSome(token) ? token.value.identity : null,
      signedIn: Option4.isSome(token),
      pendingSignIn: runtime.pendingSignIn,
      linked: link2 !== null,
      tunnel: runtime.tunnel,
      hostname: runtime.hostname,
      error: runtime.error,
      config
    };
  });
  const publishStatus = status.pipe(Effect8.flatMap((current) => ctx.reportStatus(current.error ?? (current.linked ? current.tunnel === "connected" && current.hostname ? `Linked · ${current.hostname}` : current.tunnel === "off" ? "Linked" : `Linked · tunnel ${current.tunnel}` : current.signedIn ? "Signed in, not linked" : "Not signed in"))), Effect8.ignore);
  const validToken = Effect8.gen(function* () {
    const stored = yield* readJson(KEYS.token, StoredToken);
    if (Option4.isNone(stored)) {
      return yield* new PluginError5({ message: "Sign in to T3 Connect first." });
    }
    const config = yield* readConfig;
    const fresh = yield* refreshIfNeeded(config, stored.value);
    if (Option4.isNone(fresh)) {
      yield* ctx.storage.remove(KEYS.token);
      return yield* new PluginError5({ message: "The T3 Connect sign-in expired. Sign in again." });
    }
    if (fresh.value !== stored.value)
      yield* writeJson(KEYS.token, StoredToken, fresh.value);
    return fresh.value;
  });
  const stopTunnel = Effect8.gen(function* () {
    const scope2 = tunnelScope;
    tunnelScope = null;
    if (scope2 !== null)
      yield* Scope.close(scope2, Exit.void);
    yield* Ref.update(state, (current) => ({ ...current, tunnel: "off", hostname: null }));
  });
  const readHostname = (metricsAddress) => HttpClient7.HttpClient.pipe(Effect8.flatMap((client) => client.get(`http://${metricsAddress}/config`)), Effect8.flatMap(HttpClientResponse4.schemaBodyJson(ConnectorConfigBody)), Effect8.map((body) => body.config.ingress?.find((rule) => rule.hostname)?.hostname ?? null), Effect8.timeout("5 seconds"), Effect8.orElseSucceed(() => null));
  const relinkAfterRejection = Effect8.gen(function* () {
    const now = yield* Clock2.currentTimeMillis;
    const since = now - lastRecoveryAt;
    recoveryCooldown = since > Duration2.toMillis(recoveryCooldown) + 10 * 60000 ? RECOVERY_COOLDOWN : Duration2.min(Duration2.times(recoveryCooldown, 2), RECOVERY_MAX_COOLDOWN);
    const wait = Duration2.toMillis(recoveryCooldown) - since;
    if (wait > 0)
      yield* Effect8.sleep(Duration2.millis(wait));
    lastRecoveryAt = yield* Clock2.currentTimeMillis;
    yield* Effect8.logWarning("T3 Connect rejected the tunnel; linking again");
    yield* link.pipe(Effect8.catch((error) => setState({ error: error.message })));
  });
  let rejections = 0;
  const onConnectorLine = (line) => {
    switch (classifyConnectorLine(line)) {
      case "connected":
        rejections = 0;
        return Ref.get(state).pipe(Effect8.flatMap((current) => current.tunnel === "connected" ? Effect8.void : setState({ tunnel: "connected", error: null })));
      case "metrics": {
        const address = METRICS_LINE.exec(line)?.[1];
        if (address === undefined)
          return Effect8.void;
        return Effect8.sleep("5 seconds").pipe(Effect8.andThen(readHostname(address)), Effect8.flatMap((hostname2) => hostname2 ? setState({ hostname: hostname2 }) : Effect8.void), Effect8.forkIn(pluginScope), Effect8.asVoid);
      }
      case "rejected":
        rejections += 1;
        return rejections === REJECTIONS_BEFORE_RELINK ? relinkAfterRejection.pipe(Effect8.forkIn(pluginScope), Effect8.asVoid) : Effect8.void;
      case "other":
        return Effect8.logDebug("cloudflared", { line });
    }
  };
  const superviseTunnel = Effect8.fn("bridge.superviseTunnel")(function* (runtime) {
    const executable = yield* ensureCloudflared(ctx.dataDir);
    let backoffMs = 1000;
    while (true) {
      yield* setState({ tunnel: "starting" });
      const startedAt = yield* Clock2.currentTimeMillis;
      rejections = 0;
      const exit2 = yield* Effect8.scoped(spawnConnector({
        executable,
        connectorToken: runtime.connectorToken,
        onLine: (line) => provided(onConnectorLine(line))
      }).pipe(Effect8.flatMap((child) => child.exitCode))).pipe(Effect8.exit);
      const uptime = (yield* Clock2.currentTimeMillis) - startedAt;
      backoffMs = uptime > 30000 ? 1000 : Math.min(backoffMs * 2, 60000);
      yield* Effect8.logWarning("cloudflared exited; restarting", { exit: exit2, backoffMs });
      yield* setState({ tunnel: "failed" });
      yield* Effect8.sleep(Duration2.millis(backoffMs));
    }
  }, Effect8.catch((error) => setState({ tunnel: "failed", error: error.message })));
  const startTunnel = Effect8.fn("bridge.startTunnel")(function* (runtime) {
    yield* stopTunnel;
    if (runtime === null || runtime.providerKind !== "cloudflare_tunnel")
      return;
    const scope2 = yield* Scope.fork(pluginScope);
    tunnelScope = scope2;
    yield* superviseTunnel(runtime).pipe(Effect8.forkIn(scope2));
  });
  const linkUnlocked = Effect8.gen(function* () {
    const config = yield* readConfig;
    const token = yield* validToken;
    const relayUrl = normalizeRelayUrl(config.relayUrl);
    if (relayUrl === null) {
      return yield* new PluginError5({ message: "The relay URL must be an HTTPS origin." });
    }
    const local = parseLocalOrigin(yield* ingressOrigin);
    const capabilities = {
      notificationsEnabled: true,
      liveActivitiesEnabled: true,
      managedTunnelsEnabled: true
    };
    const challenge = yield* relayRequest({
      method: "POST",
      url: `${relayUrl}/v1/client/environment-link-challenges`,
      bearer: token.accessToken,
      body: capabilities,
      schema: LinkChallengeResponse
    });
    const [environmentId, descriptor, keys] = yield* Effect8.all([
      ctx.environment.environmentId,
      ctx.environment.descriptor,
      signingKey
    ]);
    const nowSeconds2 = Math.floor((yield* Clock2.currentTimeMillis) / 1000);
    const issuedAt = (yield* unverifiedIssuedAt(challenge.challenge)) ?? nowSeconds2;
    const proof = yield* signJwt({
      privateKeyPem: keys.privateKey,
      typ: RELAY_LINK_PROOF_TYP,
      payload: {
        iss: `t3-env:${environmentId}`,
        aud: normalizeIssuer(relayUrl),
        sub: environmentId,
        jti: yield* uuid,
        iat: issuedAt,
        exp: issuedAt + 5 * 60,
        challenge: challenge.challenge,
        descriptor,
        environmentId,
        environmentPublicKey: keys.publicKey.trim(),
        endpoint: {
          httpBaseUrl: local.httpBaseUrl,
          wsBaseUrl: local.wsBaseUrl,
          providerKind: "cloudflare_tunnel"
        },
        origin: local.origin,
        scopes: ["agent_activity_notifications", "managed_tunnels"]
      }
    });
    const linked = yield* relayRequest({
      method: "POST",
      url: `${relayUrl}/v1/client/environment-links`,
      bearer: token.accessToken,
      body: { proof, ...capabilities },
      schema: LinkResponse,
      timeout: "2 minutes"
    });
    if (!(yield* isValidPublicKey(linked.cloudMintPublicKey))) {
      return yield* new PluginError5({ message: "T3 Connect returned an invalid signing key." });
    }
    yield* writeJson(KEYS.link, StoredLink, {
      relayUrl,
      relayIssuer: linked.relayIssuer,
      cloudUserId: linked.cloudUserId,
      environmentCredential: linked.environmentCredential,
      cloudMintPublicKey: linked.cloudMintPublicKey,
      endpointRuntime: linked.endpointRuntime
    });
    yield* ctx.storage.set(KEYS.wantLinked, "true");
    yield* setState({ error: null });
    yield* startTunnel(linked.endpointRuntime);
    yield* onLinked;
  }).pipe(Effect8.mapError(toPluginError));
  const link = linkLock.withPermits(1)(linkUnlocked.pipe(Effect8.tapError((error) => setState({ error: error.message }))));
  const releaseTunnel = Effect8.gen(function* () {
    const storedLink = yield* readLink;
    yield* stopTunnel;
    if (storedLink?.endpointRuntime == null)
      return;
    const token = yield* validToken;
    const environmentId = yield* ctx.environment.environmentId;
    yield* relayRequest({
      method: "DELETE",
      url: `${storedLink.relayUrl}/v1/client/environment-links/${encodeURIComponent(environmentId)}/tunnel`,
      bearer: token.accessToken,
      schema: OkResponse,
      timeout: "5 seconds"
    });
    yield* writeJson(KEYS.link, StoredLink, { ...storedLink, endpointRuntime: null });
  }).pipe(Effect8.catch((error) => Effect8.logWarning("Could not release the T3 Connect tunnel", { error })));
  const unlinkUnlocked = Effect8.gen(function* () {
    const [storedLink, config] = yield* Effect8.all([readLink, readConfig]);
    yield* stopTunnel;
    yield* ctx.storage.remove(KEYS.wantLinked);
    const relayUrl = storedLink?.relayUrl ?? normalizeRelayUrl(config.relayUrl);
    const environmentId = yield* ctx.environment.environmentId;
    const token = yield* validToken.pipe(Effect8.option);
    if (relayUrl !== null && Option4.isSome(token)) {
      yield* relayRequest({
        method: "DELETE",
        url: `${relayUrl}/v1/client/environment-links/${encodeURIComponent(environmentId)}`,
        bearer: token.value.accessToken,
        schema: OkResponse
      }).pipe(Effect8.catch((error) => Effect8.logWarning("T3 Connect did not confirm the unlink", { error })));
    }
    yield* ctx.storage.remove(KEYS.link);
    yield* ctx.deviceAccess.revokeAll;
    yield* setState({ error: null });
  });
  const unlink = linkLock.withPermits(1)(unlinkUnlocked);
  const cancelSignIn = Effect8.gen(function* () {
    const fiber = signInFiber;
    signInFiber = null;
    if (fiber !== null)
      yield* Fiber.interrupt(fiber);
    yield* Ref.update(state, (current) => ({ ...current, pendingSignIn: null }));
  });
  const signIn = Effect8.gen(function* () {
    if ((yield* Ref.get(state)).pendingSignIn !== null)
      return;
    const config = yield* readConfig;
    const authorization = yield* startDeviceAuthorization(config);
    yield* setState({
      pendingSignIn: {
        verificationUrl: authorization.verificationUrl,
        userCode: authorization.userCode
      },
      error: null
    });
    signInFiber = yield* pollDeviceToken(config, authorization).pipe(Effect8.flatMap((token) => writeJson(KEYS.token, StoredToken, token)), Effect8.andThen(setState({ pendingSignIn: null })), Effect8.andThen(link), Effect8.catch((error) => setState({ pendingSignIn: null, error: error.message })), Effect8.ensuring(Effect8.sync(() => signInFiber = null)), Effect8.forkIn(pluginScope));
  });
  const signOut = Effect8.gen(function* () {
    yield* cancelSignIn;
    yield* unlink;
    yield* ctx.storage.remove(KEYS.token);
    yield* setState({ error: null });
  });
  const setConfig = Effect8.fn("bridge.setConfig")(function* (patch) {
    const current = yield* readConfig;
    const next = { ...current, ...patch };
    if (normalizeRelayUrl(next.relayUrl) === null) {
      return yield* new PluginError5({ message: "The relay URL must be an HTTPS origin." });
    }
    yield* writeJson(KEYS.config, BridgeConfig, next);
  });
  const nowSeconds = Clock2.currentTimeMillis.pipe(Effect8.map((ms) => Math.floor(ms / 1000)));
  const reject = (status2, message) => Effect8.succeed({ status: status2, body: { _tag: "EnvironmentHttpError", message } });
  const verifyRelayProof = Effect8.fn("bridge.verifyRelayProof")(function* (body, schema, typ, accept) {
    const request2 = decodeProofRequest(body);
    const storedLink = yield* readLink.pipe(Effect8.orElseSucceed(() => null));
    if (Option4.isNone(request2) || storedLink === null)
      return null;
    const environmentId = yield* ctx.environment.environmentId;
    const claims = yield* verifyJwt(schema, {
      publicKeyPem: storedLink.cloudMintPublicKey,
      token: request2.value.proof,
      typ,
      issuer: normalizeIssuer(storedLink.relayIssuer),
      audience: `t3-env:${environmentId}`
    }).pipe(Effect8.option);
    if (Option4.isNone(claims) || !hasBoundedLifetime({ ...claims.value, nowSeconds: yield* nowSeconds }) || !accept(claims.value, { environmentId, cloudUserId: storedLink.cloudUserId })) {
      return null;
    }
    const fresh = consumeReplay([`${typ}:jti:${claims.value.jti}`, `${typ}:nonce:${claims.value.nonce}`], yield* Clock2.currentTimeMillis);
    return fresh ? { claims: claims.value, storedLink, environmentId } : "replayed";
  });
  const health = Effect8.fn("bridge.health")(function* (body) {
    const verified = yield* verifyRelayProof(body, HealthProofPayload, RELAY_HEALTH_REQUEST_TYP, (claims, context2) => claims.environmentId === context2.environmentId && claims.sub === context2.cloudUserId && hasExactScope(claims.scope, "environment:status"));
    if (verified === null)
      return yield* reject(401, "Invalid T3 Connect health request.");
    if (verified === "replayed")
      return yield* reject(409, "Health request already used.");
    const keys = yield* signingKey;
    const descriptor = yield* ctx.environment.descriptor;
    const issuedAt = yield* nowSeconds;
    const checkedAt = isoFromSeconds(issuedAt);
    const proof = yield* signJwt({
      privateKeyPem: keys.privateKey,
      typ: RELAY_HEALTH_RESPONSE_TYP,
      payload: {
        iss: `t3-env:${verified.environmentId}`,
        aud: normalizeIssuer(verified.storedLink.relayIssuer),
        sub: verified.environmentId,
        jti: yield* uuid,
        iat: issuedAt,
        exp: issuedAt + 5 * 60,
        environmentId: verified.environmentId,
        requestNonce: verified.claims.nonce,
        status: "online",
        descriptor,
        checkedAt
      }
    });
    return {
      status: 200,
      body: {
        environmentId: verified.environmentId,
        status: "online",
        descriptor,
        checkedAt,
        proof
      }
    };
  }, Effect8.catch((error) => reject(500, error.message)));
  const mintCredential = Effect8.fn("bridge.mintCredential")(function* (body) {
    const verified = yield* verifyRelayProof(body, MintCredentialProofPayload, RELAY_MINT_REQUEST_TYP, (claims, context2) => claims.environmentId === context2.environmentId && claims.sub === context2.cloudUserId && claims.cnf.jkt === claims.clientProofKeyThumbprint && hasExactScope(claims.scope, "environment:connect"));
    if (verified === null)
      return yield* reject(401, "Invalid T3 Connect mint request.");
    if (verified === "replayed")
      return yield* reject(409, "Mint request already used.");
    const issued = yield* ctx.deviceAccess.issueCredential({
      proofKeyThumbprint: verified.claims.clientProofKeyThumbprint,
      label: "T3 Connect"
    });
    const keys = yield* signingKey;
    const issuedAt = yield* nowSeconds;
    const proof = yield* signJwt({
      privateKeyPem: keys.privateKey,
      typ: RELAY_MINT_RESPONSE_TYP,
      payload: {
        iss: `t3-env:${verified.environmentId}`,
        aud: normalizeIssuer(verified.storedLink.relayIssuer),
        sub: verified.environmentId,
        jti: yield* uuid,
        iat: issuedAt,
        exp: Math.floor(issued.expiresAt.epochMilliseconds / 1000),
        environmentId: verified.environmentId,
        clientProofKeyThumbprint: verified.claims.clientProofKeyThumbprint,
        requestNonce: verified.claims.nonce,
        credential: issued.credential
      }
    });
    return {
      status: 200,
      body: {
        credential: issued.credential,
        expiresAt: DateTime.formatIso(issued.expiresAt),
        proof
      }
    };
  }, Effect8.catch((error) => reject(500, error.message)));
  const resume = Effect8.gen(function* () {
    const wanted = yield* ctx.storage.get(KEYS.wantLinked);
    if (Option4.isNone(wanted))
      return;
    yield* link.pipe(Effect8.retry({
      while: (error) => error.message.startsWith("Could not reach"),
      schedule: Schedule.exponential("5 seconds"),
      times: 8
    }), Effect8.ignore);
  });
  yield* publishStatus;
  yield* Effect8.addFinalizer(() => cancelSignIn.pipe(Effect8.andThen(releaseTunnel), Effect8.ignore));
  yield* resume.pipe(Effect8.forkIn(pluginScope));
  const withStatus = (effect) => provided(effect.pipe(Effect8.andThen(publishStatus), Effect8.andThen(status)));
  return {
    readLink,
    readConfig,
    signingKey: provided(signingKey),
    routes: {
      health: (body) => provided(health(body)),
      mintCredential: (body) => provided(mintCredential(body))
    },
    actions: {
      status: () => provided(status),
      signIn: () => withStatus(signIn),
      signOut: () => withStatus(signOut),
      link: () => withStatus(link),
      unlink: () => withStatus(unlink),
      setConfig: (patch) => withStatus(setConfig(patch))
    }
  };
});

// src/push.ts
import { PluginContext as PluginContext2 } from "@t3tools/plugin-api";
import * as Clock3 from "effect/Clock";
import * as SecureRandom3 from "effect/crypto/SecureRandom";
import * as Effect9 from "effect/Effect";
import * as Option5 from "effect/Option";
import * as Queue from "effect/Queue";
import * as Schema8 from "effect/Schema";
import * as Stream2 from "effect/Stream";
var CONFIRM_DELAY_MS = 5000;
var RETRY_DELAYS_MS = [1000, 4000, 16000, 60000];
var DETAIL_MAX_LENGTH = 160;
var CLEARED = "null";
var decodeState = Schema8.decodeUnknownOption(AgentActivityState);
function publishIdentity(state) {
  if (state === null)
    return CLEARED;
  const { updatedAt: _updatedAt, ...rest } = state;
  return JSON.stringify(rest);
}
function needsConfirmation(state) {
  return state === null || state.phase === "completed";
}
function toRelayState(state) {
  if (state === null)
    return Option5.some(null);
  const detail = state.detail?.trim().slice(0, DETAIL_MAX_LENGTH).trim();
  const { detail: _detail, ...rest } = state;
  return decodeState(detail ? { ...rest, detail } : rest);
}
var runActivityPublisher = Effect9.fn("bridge.push.run")(function* (input) {
  const ctx = yield* PluginContext2;
  const queue = yield* Queue.unbounded();
  const queued = new Set;
  const published = new Map;
  const confirmDeadlines = new Map;
  const attempts = new Map;
  let publishedCredential = null;
  const enqueue = (threadId) => Effect9.suspend(() => {
    if (queued.has(threadId))
      return Effect9.void;
    queued.add(threadId);
    return Queue.offer(queue, threadId).pipe(Effect9.asVoid);
  });
  const enqueueLater = (threadId, delayMs) => Effect9.sleep(delayMs).pipe(Effect9.andThen(enqueue(threadId)), Effect9.forkScoped, Effect9.asVoid);
  const publish = Effect9.fn("bridge.push.publish")(function* (threadId) {
    const [config, link] = yield* Effect9.all([input.readConfig, input.readLink]);
    if (!config.pushNotifications || link === null) {
      published.clear();
      publishedCredential = null;
      return;
    }
    if (publishedCredential !== link.environmentCredential) {
      published.clear();
      publishedCredential = link.environmentCredential;
    }
    const state = yield* ctx.agentActivity.read(threadId);
    const identity = publishIdentity(state);
    const previous = published.get(threadId);
    if (previous === identity)
      return;
    const hadLiveState = previous !== undefined && previous !== CLEARED;
    if (!hadLiveState && (state === null || state.phase === "completed" || state.phase === "failed")) {
      return;
    }
    if (needsConfirmation(state)) {
      const now = yield* Clock3.currentTimeMillis;
      const deadline = confirmDeadlines.get(threadId);
      if (deadline === undefined) {
        confirmDeadlines.set(threadId, now + CONFIRM_DELAY_MS);
        return yield* enqueueLater(threadId, CONFIRM_DELAY_MS);
      }
      if (now < deadline)
        return;
    }
    confirmDeadlines.delete(threadId);
    const relayState = toRelayState(state);
    if (Option5.isNone(relayState)) {
      return yield* Effect9.logDebug("Skipping agent activity the relay would reject", { threadId });
    }
    const environmentId = yield* ctx.environment.environmentId;
    const keys = yield* input.signingKey;
    const issuedAt = Math.floor((yield* Clock3.currentTimeMillis) / 1000);
    const proof = yield* signJwt({
      privateKeyPem: keys.privateKey,
      typ: RELAY_ACTIVITY_PUBLISH_TYP,
      payload: {
        iss: `t3-env:${environmentId}`,
        aud: normalizeIssuer(link.relayIssuer),
        sub: environmentId,
        jti: yield* SecureRandom3.SecureRandom.pipe(Effect9.flatMap((random) => random.uuidV4())),
        iat: issuedAt,
        exp: issuedAt + 5 * 60,
        environmentId,
        threadId,
        state: relayState.value
      }
    });
    yield* relayRequest({
      method: "POST",
      url: `${link.relayUrl}/v1/environments/${encodeURIComponent(environmentId)}/threads/${encodeURIComponent(threadId)}/agent-activity`,
      bearer: link.environmentCredential,
      body: { state: relayState.value, proof },
      schema: PublishResponse
    });
    published.set(threadId, identity);
  });
  const processThread = (threadId) => Effect9.sync(() => queued.delete(threadId)).pipe(Effect9.andThen(publish(threadId)), Effect9.tap(() => Effect9.sync(() => attempts.delete(threadId))), Effect9.catch((error) => {
    const attempt = attempts.get(threadId) ?? 0;
    attempts.set(threadId, attempt + 1);
    const delay = RETRY_DELAYS_MS[attempt] ?? 60000;
    return Effect9.logWarning("Could not publish agent activity to T3 Connect", {
      threadId,
      error: error.message
    }).pipe(Effect9.andThen(enqueueLater(threadId, delay)));
  }));
  const catchUp = ctx.agentActivity.activeThreadIds.pipe(Effect9.flatMap((ids) => Effect9.forEach(ids, enqueue, { discard: true })), Effect9.catch((error) => Effect9.logWarning("Could not read active threads", { error })));
  yield* Stream2.runForEach(ctx.agentActivity.changes, enqueue).pipe(Effect9.forkScoped);
  yield* catchUp;
  yield* Queue.take(input.catchUpRequests).pipe(Effect9.andThen(catchUp), Effect9.forever, Effect9.forkScoped);
  return yield* Queue.take(queue).pipe(Effect9.flatMap(processThread), Effect9.forever);
});

// src/index.ts
var t3ConnectBridge = definePlugin({
  manifest: {
    id: T3_CONNECT_BRIDGE_ID,
    name: "Unofficial T3 Connect bridge",
    description: "Links this environment to the official T3 Connect service, so T3 Code apps signed in to your T3 account can reach it and the store mobile app gets push notifications.",
    version: "0.1.0",
    unofficial: true,
    externalServices: ["relay.t3.codes", "clerk.t3.codes", "Cloudflare Tunnel"],
    capabilities: [
      "network:outbound",
      "process:spawn",
      "http:routes",
      "auth:issue-device-credentials",
      "orchestration:read-activity"
    ],
    httpRoutes: [HEALTH_ROUTE, MINT_ROUTE]
  },
  actions: bridgeActions,
  start: Effect10.gen(function* () {
    const catchUpRequests = yield* Queue2.sliding(1);
    const bridge = yield* makeBridge(Queue2.offer(catchUpRequests, undefined).pipe(Effect10.asVoid));
    yield* runActivityPublisher({
      readLink: bridge.readLink,
      readConfig: bridge.readConfig,
      signingKey: bridge.signingKey,
      catchUpRequests
    }).pipe(Effect10.catchCause((cause) => Effect10.logError("T3 Connect activity publisher stopped", { cause })), Effect10.forkScoped);
    return {
      actions: bridge.actions,
      routes: {
        [HEALTH_ROUTE]: bridge.routes.health,
        [MINT_ROUTE]: bridge.routes.mintCredential
      }
    };
  })
});
export {
  t3ConnectBridge
};
